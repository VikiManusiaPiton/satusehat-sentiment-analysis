@echo off
title SatuSehat Sentiment AI - Starter
color 0A

echo ========================================================
echo       MEMULAI LAYANAN SATUSEHAT SENTIMENT AI
echo ========================================================
echo.

:: 1. Cek & Start MySQL jika belum jalan
echo [1/3] Memeriksa MySQL...
netstat -ano | findstr :3306 >nul
if %errorlevel% neq 0 (
    echo Menjalankan MySQL...
    start /b "" "C:\xampp\mysql\bin\mysqld.exe" --defaults-file="C:\xampp\mysql\bin\my.ini" --standalone
    timeout /t 2 >nul
) else (
    echo MySQL sudah aktif di port 3306.
)

:: 2. Cek & Start Python FastAPI jika belum jalan
echo [2/3] Memeriksa Python FastAPI...
netstat -ano | findstr :5000 >nul
if %errorlevel% neq 0 (
    echo Menjalankan Python FastAPI di port 5000...
    start "FastAPI Service (Port 5000)" /min "C:\Users\MyBook Hype AMD\AppData\Local\Programs\Python\Python312\python.exe" "c:\xampp\htdocs\satu_sehat\sentiment-api\run_api.py"
    timeout /t 3 >nul
) else (
    echo Python FastAPI sudah aktif di port 5000.
)

:: 3. Cek & Start CodeIgniter 4
echo [3/3] Memeriksa Web CodeIgniter 4...
netstat -ano | findstr :8080 >nul
if %errorlevel% neq 0 (
    echo Menjalankan Web Server di port 8080...
    start "CI4 Web Server (Port 8080)" /min php spark serve --port 8080
    timeout /t 2 >nul
) else (
    echo CodeIgniter 4 sudah aktif di port 8080.
)

echo.
echo ========================================================
echo SEMUA LAYANAN TELAH AKTIF!
echo Buka di browser: http://localhost:8080/analisis
echo ========================================================
pause
