<?php

namespace App\Models;

use CodeIgniter\Model;

class BatchUploadModel extends Model
{
    protected $table            = 'batch_uploads';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'filename',
        'total_rows',
        'created_at',
    ];

    protected $useTimestamps = false;
}
