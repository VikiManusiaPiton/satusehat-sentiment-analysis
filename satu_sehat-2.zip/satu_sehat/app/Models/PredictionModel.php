<?php

namespace App\Models;

use CodeIgniter\Model;

class PredictionModel extends Model
{
    protected $table            = 'predictions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'text_original',
        'text_clean',
        'label',
        'confidence',
        'prob_positif',
        'prob_negatif',
        'top_words',
        'category',
        'source',
        'created_at',
    ];

    protected $useTimestamps = false;

    /**
     * Mengambil ringkasan statistik KPI untuk dashboard
     */
    public function getSummaryStats(): array
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        // Agregasi terisolasi dan atomic dalam 1 query SQL tanpa efek samping stateful
        $row = $builder->select("
            COUNT(*) as total,
            SUM(CASE WHEN LOWER(label) = 'positif' THEN 1 ELSE 0 END) as positive_count,
            SUM(CASE WHEN LOWER(label) = 'negatif' THEN 1 ELSE 0 END) as negative_count,
            SUM(CASE WHEN LOWER(label) NOT IN ('positif', 'negatif') THEN 1 ELSE 0 END) as other_count,
            AVG(CASE WHEN confidence IS NOT NULL AND confidence > 0 AND LOWER(label) IN ('positif', 'negatif') THEN confidence ELSE NULL END) as avg_conf,
            COUNT(CASE WHEN confidence IS NOT NULL AND confidence > 0 AND LOWER(label) IN ('positif', 'negatif') THEN 1 ELSE NULL END) as valid_conf_count
        ")->get()->getRowArray();

        $total = (int)($row['total'] ?? 0);
        $positiveCount = (int)($row['positive_count'] ?? 0);
        $negativeCount = (int)($row['negative_count'] ?? 0);
        $otherCount = (int)($row['other_count'] ?? 0);
        $validConfCount = (int)($row['valid_conf_count'] ?? 0);
        $avgConfRaw = $row['avg_conf'];

        // Format persentase rata-rata confidence jika ada data valid
        $avgConfidence = ($validConfCount > 0 && $avgConfRaw !== null) ? round((float)$avgConfRaw * 100, 1) : null;

        // Persentase sentimen dihitung dari total ulasan sentimen yang valid (Positif + Negatif)
        $validSentimentTotal = $positiveCount + $negativeCount;
        $positivePct = $validSentimentTotal > 0 ? round(($positiveCount / $validSentimentTotal) * 100, 1) : 0;
        $negativePct = $validSentimentTotal > 0 ? round(($negativeCount / $validSentimentTotal) * 100, 1) : 0;

        return [
            'total'            => $total,
            'positive_count'   => $positiveCount,
            'negative_count'   => $negativeCount,
            'other_count'      => $otherCount,
            'positive_pct'     => $positivePct,
            'negative_pct'     => $negativePct,
            'avg_confidence'   => $avgConfidence,
            'valid_conf_count' => $validConfCount,
        ];
    }

    /**
     * Mengambil tren prediksi harian (misal 7-14 hari terakhir yang ada data)
     */
    public function getDailyTrend(int $days = 14): array
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $results = $builder->select("DATE(created_at) as date, label, COUNT(*) as count")
            ->where("created_at >=", date('Y-m-d H:i:s', strtotime("-{$days} days")))
            ->groupBy("DATE(created_at), label")
            ->orderBy("date", "ASC")
            ->get()
            ->getResultArray();

        $dailyData = [];
        foreach ($results as $row) {
            $d = $row['date'];
            if (!isset($dailyData[$d])) {
                $dailyData[$d] = ['date' => $d, 'positif' => 0, 'negatif' => 0, 'total' => 0];
            }
            if (strcasecmp($row['label'], 'Positif') === 0) {
                $dailyData[$d]['positif'] += (int)$row['count'];
            } else if (strcasecmp($row['label'], 'Negatif') === 0) {
                $dailyData[$d]['negatif'] += (int)$row['count'];
            }
            $dailyData[$d]['total'] += (int)$row['count'];
        }

        return array_values($dailyData);
    }

    /**
     * Mengambil agregasi keluhan terbanyak untuk ulasan Negatif
     */
    public function getTopComplaints(int $limit = 6): array
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        return $builder->select("category, COUNT(*) as count")
            ->where('LOWER(label)', 'negatif')
            ->where('category IS NOT NULL')
            ->where("category != ''")
            ->groupBy('category')
            ->orderBy('count', 'DESC')
            ->limit($limit)
            ->get()
            ->getResultArray();
    }

    /**
     * Mengambil frekuensi kata teratas untuk ulasan Positif dan Negatif (Word Cloud)
     */
    public function getTopWordsBySentiment(string $label, int $limit = 15): array
    {
        $db = \Config\Database::connect();
        $rows = $db->table($this->table)
            ->select('top_words')
            ->where('LOWER(label)', strtolower($label))
            ->where('top_words IS NOT NULL')
            ->orderBy('id', 'DESC')
            ->limit(300)
            ->get()
            ->getResultArray();

        $wordFreq = [];
        foreach ($rows as $r) {
            $words = json_decode($r['top_words'], true);
            if (is_array($words)) {
                foreach ($words as $w) {
                    $term = trim($w['word'] ?? '');
                    if ($term && strlen($term) > 2) {
                        $wordFreq[$term] = ($wordFreq[$term] ?? 0) + 1;
                    }
                }
            }
        }

        arsort($wordFreq);
        $result = [];
        $i = 0;
        foreach ($wordFreq as $word => $count) {
            if ($i++ >= $limit) break;
            $result[] = ['word' => $word, 'count' => $count];
        }
        return $result;
    }
}
