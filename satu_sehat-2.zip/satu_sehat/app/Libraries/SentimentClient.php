<?php

namespace App\Libraries;

use CodeIgniter\HTTP\CURLRequest;
use Config\Services;
use Exception;

class SentimentClient
{
    protected string $baseUrl;
    protected CURLRequest $client;
    protected int $timeout = 120; // 120 detik untuk mengakomodasi pemrosesan hingga 5.000 baris

    public function __construct()
    {
        // Ambil URL dari environment variabel sentiment.api.url, default http://127.0.0.1:5000
        $url = env('sentiment.api.url', 'http://127.0.0.1:5000');
        $this->baseUrl = rtrim($url, '/');
        $this->client = Services::curlrequest([
            'base_uri'    => $this->baseUrl,
            'timeout'     => $this->timeout,
            'http_errors' => false,
        ]);
    }

    /**
     * Memeriksa kesehatan Python FastAPI service
     */
    public function health(): bool
    {
        try {
            $response = $this->client->get($this->baseUrl . '/health');
            if ($response->getStatusCode() === 200) {
                $body = json_decode($response->getBody(), true);
                return isset($body['status']) && $body['status'] === 'ok';
            }
            return false;
        } catch (Exception $e) {
            log_message('error', 'SentimentClient health check failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Mengirim 1 ulasan untuk diprediksi
     */
    public function predict(string $text): array
    {
        try {
            $response = $this->client->post($this->baseUrl . '/predict', [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ],
                'json' => [
                    'text' => $text,
                ],
            ]);

            $statusCode = $response->getStatusCode();
            $body = json_decode($response->getBody(), true);

            if ($statusCode === 200 && is_array($body)) {
                return [
                    'success' => true,
                    'data'    => $body,
                ];
            }

            $errorMessage = $body['detail'] ?? ($body['message'] ?? 'Gagal memproses prediksi dari model.');
            return [
                'success' => false,
                'message' => $errorMessage,
            ];
        } catch (Exception $e) {
            log_message('error', 'SentimentClient predict error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Layanan analisis sedang tidak tersedia. Pastikan service Python API aktif.',
            ];
        }
    }

    /**
     * Mengirim daftar ulasan secara massal (batch)
     */
    public function predictBatch(array $texts): array
    {
        try {
            $response = $this->client->post($this->baseUrl . '/predict-batch', [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ],
                'json' => [
                    'texts' => $texts,
                ],
            ]);

            $statusCode = $response->getStatusCode();
            $body = json_decode($response->getBody(), true);

            if ($statusCode === 200 && is_array($body)) {
                return [
                    'success' => true,
                    'data'    => $body,
                ];
            }

            $errorMessage = $body['detail'] ?? ($body['message'] ?? 'Gagal memproses prediksi batch.');
            return [
                'success' => false,
                'message' => $errorMessage,
            ];
        } catch (Exception $e) {
            log_message('error', 'SentimentClient predictBatch error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Layanan analisis sedang tidak tersedia saat memproses data massal.',
            ];
        }
    }

    /**
     * Mengambil metrik evaluasi model
     */
    public function getMetrics(): array
    {
        try {
            $response = $this->client->get($this->baseUrl . '/metrics', [
                'headers' => [
                    'Accept' => 'application/json',
                ],
            ]);

            $statusCode = $response->getStatusCode();
            $body = json_decode($response->getBody(), true);

            if ($statusCode === 200 && is_array($body)) {
                return [
                    'success' => true,
                    'data'    => $body,
                ];
            }

            return [
                'success' => false,
                'message' => 'Gagal mengambil data metrik evaluasi model.',
            ];
        } catch (Exception $e) {
            log_message('error', 'SentimentClient getMetrics error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Layanan analisis sedang tidak tersedia untuk membaca metrik performa.',
            ];
        }
    }
}
