<?php

namespace App\Libraries;

class ComplaintCategorizer
{
    /**
     * Pola aturan kata kunci untuk 6 kategori keluhan ulasan negatif
     */
    protected static array $categories = [
        'OTP/verifikasi' => [
            'otp', 'kode', 'verifikasi', 'sms', 'email', 'nomor hp', 'wa', 'whatsapp', 'kode verifikasi'
        ],
        'Sertifikat vaksin tidak muncul' => [
            'sertifikat', 'vaksin', 'muncul', 'booster', 'klaim', 'download sertifikat', 'kartu vaksin'
        ],
        'Input data/tanggal lahir' => [
            'tanggal lahir', 'nik', 'tidak bisa isi', 'input data', 'format tanggal', 'isi form', 'data anak'
        ],
        'Performa/error' => [
            'lemot', 'error', 'force close', 'update', 'lag', 'blank', 'crash', 'macet', 'lambat', 'bug', 'server'
        ],
        'Login/registrasi' => [
            'login', 'daftar', 'registrasi gagal', 'masuk akun', 'password', 'kata sandi', 'buat akun'
        ],
        'Lokasi/scan QR' => [
            'lokasi', 'radius', 'scan', 'barcode', 'qr', 'gps', 'check in', 'faskes'
        ],
    ];

    /**
     * Mengklasifikasikan ulasan negatif ke salah satu kategori keluhan berbasis pencocokan kata kunci
     */
    public static function categorize(string $textOriginal, string $textClean = ''): ?string
    {
        $haystack = strtolower($textOriginal . ' ' . $textClean);
        $bestCategory = null;
        $maxMatches = 0;

        foreach (self::$categories as $categoryName => $keywords) {
            $matches = 0;
            foreach ($keywords as $keyword) {
                if (stripos($haystack, $keyword) !== false) {
                    $matches += 1;
                }
            }

            if ($matches > $maxMatches) {
                $maxMatches = $matches;
                $bestCategory = $categoryName;
            }
        }

        // Jika ada kecocokan minimal 1 kata kunci, gunakan kategori tersebut, atau 'Lainnya' jika tidak cocok
        return $maxMatches > 0 ? $bestCategory : 'Lainnya';
    }

    /**
     * Mengambil daftar semua kategori
     */
    public static function getCategories(): array
    {
        return array_keys(self::$categories);
    }
}
