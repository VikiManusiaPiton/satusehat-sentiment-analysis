<?php

namespace App\Controllers;

use App\Models\PredictionModel;
use CodeIgniter\Controller;

class Riwayat extends Controller
{
    protected PredictionModel $predictionModel;

    public function __construct()
    {
        helper(['text', 'form', 'url']);
        $this->predictionModel = new PredictionModel();
    }

    public function index()
    {
        $keyword = trim((string)$this->request->getGet('q'));
        $label = trim((string)$this->request->getGet('label'));
        $startDate = trim((string)$this->request->getGet('start_date'));
        $endDate = trim((string)$this->request->getGet('end_date'));
        $perPage = 15;

        $builder = $this->predictionModel;

        if ($keyword !== '') {
            $builder = $builder->groupStart()
                ->like('text_original', $keyword)
                ->orLike('text_clean', $keyword)
                ->orLike('category', $keyword)
                ->groupEnd();
        }

        if ($label === 'Positif' || $label === 'Negatif') {
            $builder = $builder->where('label', $label);
        }

        if ($startDate !== '') {
            $builder = $builder->where('created_at >=', $startDate . ' 00:00:00');
        }

        if ($endDate !== '') {
            $builder = $builder->where('created_at <=', $endDate . ' 23:59:59');
        }

        $predictions = $builder->orderBy('id', 'DESC')->paginate($perPage, 'predictions');
        $pager = $this->predictionModel->pager;

        return view('riwayat/index', [
            'title'       => 'Riwayat Analisis Sentimen',
            'predictions' => $predictions,
            'pager'       => $pager,
            'keyword'     => $keyword,
            'selectedLabel' => $label,
            'startDate'   => $startDate,
            'endDate'     => $endDate,
            'totalCount'  => $pager->getTotal('predictions'),
        ]);
    }

    public function delete($id = null)
    {
        if (!$id) {
            return redirect()->to('/riwayat')->with('error', 'ID data tidak valid.');
        }

        $prediction = $this->predictionModel->find($id);
        if (!$prediction) {
            return redirect()->to('/riwayat')->with('error', 'Data tidak ditemukan.');
        }

        $this->predictionModel->delete($id);

        return redirect()->to('/riwayat')->with('success', 'Data prediksi berhasil dihapus.');
    }

    public function clearAll()
    {
        $this->predictionModel->emptyTable();
        return redirect()->to('/riwayat')->with('success', 'Semua riwayat prediksi berhasil dikosongkan.');
    }
}
