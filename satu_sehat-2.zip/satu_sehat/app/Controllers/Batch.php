<?php

namespace App\Controllers;

use App\Libraries\SentimentClient;
use App\Libraries\ComplaintCategorizer;
use App\Models\PredictionModel;
use App\Models\BatchUploadModel;
use CodeIgniter\Controller;

class Batch extends Controller
{
    protected SentimentClient $client;
    protected PredictionModel $predictionModel;
    protected BatchUploadModel $batchUploadModel;

    public function __construct()
    {
        $this->client = new SentimentClient();
        $this->predictionModel = new PredictionModel();
        $this->batchUploadModel = new BatchUploadModel();
    }

    public function index()
    {
        $lastBatchId = session()->getFlashdata('lastBatchId');
        $previewResults = [];
        $batchInfo = null;

        if ($lastBatchId) {
            $batchInfo = $this->batchUploadModel->find($lastBatchId);
            // Tampilkan maksimal 100 baris pertama untuk preview responsif di browser
            $previewLimit = isset($batchInfo['total_rows']) ? min((int)$batchInfo['total_rows'], 100) : 100;
            $previewResults = $this->predictionModel
                ->where('source', 'batch')
                ->orderBy('id', 'DESC')
                ->limit($previewLimit)
                ->findAll();
        }

        return view('batch/index', [
            'title'          => 'Prediksi Massal CSV - SatuSehat Sentiment',
            'previewResults' => $previewResults,
            'batchInfo'      => $batchInfo,
        ]);
    }

    public function upload()
    {
        // Tingkatkan execution time dan memory limit untuk pemrosesan hingga 5.000 baris data
        set_time_limit(300);
        ini_set('memory_limit', '512M');

        $validationRule = [
            'csv_file' => [
                'label' => 'File CSV',
                'rules' => [
                    'uploaded[csv_file]',
                    'ext_in[csv_file,csv,txt]',
                    'max_size[csv_file,5120]', // 5 MB
                ],
                'errors' => [
                    'uploaded' => 'Silakan pilih file CSV terlebih dahulu.',
                    'ext_in'   => 'Format file harus berupa CSV (.csv).',
                    'max_size' => 'Ukuran file CSV maksimal 5 MB.',
                ],
            ],
        ];

        if (!$this->validate($validationRule)) {
            return redirect()->back()->withInput()->with('error', $this->validator->getError('csv_file'));
        }

        $file = $this->request->getFile('csv_file');
        if (!$file->isValid() || $file->hasMoved()) {
            return redirect()->back()->with('error', 'File yang diunggah tidak valid.');
        }

        $filePath = $file->getTempName();

        // Deteksi delimiter otomatis (koma, titik koma, tab, pipe)
        $delimiter = $this->detectDelimiter($filePath);

        $handle = fopen($filePath, 'r');
        if (!$handle) {
            return redirect()->back()->with('error', 'Gagal membuka file CSV.');
        }

        // Baca header dengan delimiter terdeteksi
        $header = fgetcsv($handle, 4096, $delimiter);
        if (!$header) {
            fclose($handle);
            return redirect()->back()->with('error', 'File CSV kosong.');
        }

        // Cari indeks kolom 'content' (case-insensitive & pembersihan spasi/BOM)
        $contentIdx = -1;
        $foundHeaders = [];
        foreach ($header as $idx => $colName) {
            // Hapus karakter invisible / BOM UTF-8 dan kutipan/spasi
            $colClean = preg_replace('/[\x00-\x1F\x7F\xEF\xBB\xBF]/', '', (string)$colName);
            $cleanedCol = strtolower(trim($colClean, " \t\n\r\0\x0B\"'"));
            $foundHeaders[] = $cleanedCol;
            if ($cleanedCol === 'content') {
                $contentIdx = $idx;
                break;
            }
        }

        if ($contentIdx === -1) {
            fclose($handle);
            return redirect()->back()->with('error', 'File CSV wajib memiliki kolom bernama "content". Header yang terdeteksi: ' . implode(', ', $foundHeaders));
        }

        // Baca seluruh baris teks dengan delimiter yang sama (maksimal 5.000 baris)
        $rows = [];
        $lineCount = 0;
        while (($row = fgetcsv($handle, 4096, $delimiter)) !== false) {
            $text = isset($row[$contentIdx]) ? trim($row[$contentIdx]) : '';
            if ($text !== '') {
                $rows[] = $text;
                $lineCount++;
            }
            if ($lineCount > 5000) {
                fclose($handle);
                return redirect()->back()->with('error', 'Maksimal baris CSV yang diizinkan adalah 5.000 baris per unggahan.');
            }
        }
        fclose($handle);

        if (empty($rows)) {
            return redirect()->back()->with('error', 'Tidak ada data ulasan valid yang ditemukan pada kolom content.');
        }

        // Kirim ke Python API per 250 baris (chunk)
        $chunkSize = 250;
        $chunks = array_chunk($rows, $chunkSize);
        $allResults = [];

        foreach ($chunks as $chunk) {
            $apiResult = $this->client->predictBatch($chunk);
            if (!$apiResult['success']) {
                return redirect()->back()->with('error', 'Gagal memproses batch pada server AI: ' . ($apiResult['message'] ?? 'API Offline'));
            }

            foreach ($apiResult['data'] as $idx => $res) {
                $origText = $chunk[$idx];
                $label = $res['label'];
                $conf = $res['confidence'];
                $probPos = $res['prob_positif'];
                $probNeg = $res['prob_negatif'];
                $cleanText = $res['clean_text'];
                $topWords = $res['top_words'];

                $category = null;
                if ($label === 'Tidak Valid') {
                    $category = 'Teks Tidak Valid';
                } elseif ($label === 'Negatif') {
                    if (!empty($res['category'])) {
                        $category = $res['category'];
                    } else {
                        $category = ComplaintCategorizer::categorize($origText, $cleanText);
                    }
                }

                $allResults[] = [
                    'text_original' => $origText,
                    'text_clean'    => $cleanText,
                    'label'         => $label,
                    'confidence'    => $conf,
                    'prob_positif'  => $probPos,
                    'prob_negatif'  => $probNeg,
                    'top_words'     => json_encode($topWords),
                    'category'      => $category,
                    'source'        => 'batch',
                    'created_at'    => date('Y-m-d H:i:s'),
                ];
            }
        }

        // Simpan ke batch_uploads
        $batchId = $this->batchUploadModel->insert([
            'filename'   => $file->getClientName(),
            'total_rows' => count($allResults),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Simpan seluruh hasil ke predictions secara chunked (500 per batch query) agar aman bagi MySQL
        if (!empty($allResults)) {
            foreach (array_chunk($allResults, 500) as $dbChunk) {
                $this->predictionModel->insertBatch($dbChunk);
            }
        }

        session()->setFlashdata('lastBatchId', $batchId);
        return redirect()->to('/batch')->with('success', 'Berhasil memproses ' . number_format(count($allResults)) . ' ulasan secara massal!');
    }

    /**
     * Download hasil prediksi batch dalam bentuk CSV
     */
    public function download($batchId = null)
    {
        $batch = null;
        if ($batchId) {
            $batch = $this->batchUploadModel->find($batchId);
        }

        $limit = $batch ? (int)$batch['total_rows'] : 5000;
        $items = $this->predictionModel
            ->where('source', 'batch')
            ->orderBy('id', 'DESC')
            ->limit($limit)
            ->findAll();

        $filename = 'hasil_prediksi_satusehat_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);

        $output = fopen('php://output', 'w');
        // Tulis BOM untuk Excel UTF-8
        fputs($output, "\xEF\xBB\xBF");
        // Kolom wajib: content, label, confidence
        fputcsv($output, ['content', 'label', 'confidence', 'kategori_keluhan']);

        foreach ($items as $row) {
            fputcsv($output, [
                $row['text_original'],
                $row['label'],
                $row['confidence'],
                $row['category'] ?? '-'
            ]);
        }

        fclose($output);
        exit;
    }

    /**
     * Download template/sample CSV
     */
    public function sampleCsv()
    {
        $samplePath = FCPATH . '../sentiment-api/sample_ulasan_satusehat.csv';
        if (file_exists($samplePath)) {
            return $this->response->download($samplePath, null)->setFileName('sample_ulasan_satusehat.csv');
        }

        // Buat on-the-fly jika file belum ada
        $csvContent = "content\n";
        $csvContent .= "\"Sangat bagus aplikasinya, sertifikat vaksin langsung muncul\"\n";
        $csvContent .= "\"Kode OTP tidak pernah masuk ke nomor hp atau email tolong perbaiki\"\n";
        $csvContent .= "\"Aplikasi sering error force close saat mau scan QR puskesmas\"\n";
        $csvContent .= "\"Mudah digunakan untuk memantau imunisasi anak terima kasih\"\n";

        return $this->response
            ->setHeader('Content-Type', 'text/csv')
            ->setHeader('Content-Disposition', 'attachment; filename="template_ulasan.csv"')
            ->setBody($csvContent);
    }

    /**
     * Mendeteksi delimiter CSV secara otomatis (, ; \t |)
     */
    protected function detectDelimiter(string $filePath): string
    {
        $delimiters = [',', ';', "\t", '|'];
        $handle = fopen($filePath, 'r');
        if (!$handle) {
            return ',';
        }

        $firstLine = fgets($handle);
        fclose($handle);

        if (!$firstLine) {
            return ',';
        }

        // Hapus BOM UTF-8 jika ada
        $cleanLine = preg_replace('/^\xEF\xBB\xBF/', '', $firstLine);

        $counts = [];
        foreach ($delimiters as $delim) {
            $fields = str_getcsv($cleanLine, $delim);
            $counts[$delim] = count($fields);
        }

        // Prioritaskan delimiter dengan jumlah kolom terbanyak (> 1)
        arsort($counts);
        $bestDelimiter = key($counts);

        return ($counts[$bestDelimiter] > 1) ? $bestDelimiter : ',';
    }
}

