<?php

namespace App\Controllers;

use App\Libraries\SentimentClient;
use App\Libraries\ComplaintCategorizer;
use App\Models\PredictionModel;
use CodeIgniter\Controller;

class Analisis extends Controller
{
    protected SentimentClient $client;
    protected PredictionModel $predictionModel;

    public function __construct()
    {
        $this->client = new SentimentClient();
        $this->predictionModel = new PredictionModel();
    }

    public function index()
    {
        $apiOnline = $this->client->health();

        return view('analisis/index', [
            'title'     => 'Analisis Sentimen SatuSehat - Prediksi Tunggal',
            'apiOnline' => $apiOnline,
        ]);
    }

    /**
     * Endpoint AJAX /analisis/prediksi
     */
    public function prediksi()
    {
        if (!$this->request->isAJAX() && !$this->request->is('post')) {
            return $this->response->setStatusCode(405)->setJSON([
                'success' => false,
                'message' => 'Metode permintaan tidak diizinkan.'
            ]);
        }

        $rules = [
            'text' => 'required|min_length[3]|max_length[1000]',
        ];

        $messages = [
            'text' => [
                'required'   => 'Teks ulasan tidak boleh kosong.',
                'min_length' => 'Teks ulasan minimal harus memiliki 3 karakter.',
                'max_length' => 'Teks ulasan maksimal 1000 karakter.',
            ]
        ];

        if (!$this->validate($rules, $messages)) {
            $errors = $this->validator->getErrors();
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => reset($errors),
            ]);
        }

        $text = trim((string)$this->request->getPost('text'));

        // Panggil Python API via SentimentClient
        $apiResult = $this->client->predict($text);

        if (!$apiResult['success']) {
            return $this->response->setStatusCode(503)->setJSON([
                'success' => false,
                'message' => $apiResult['message'] ?? 'Layanan analisis sedang tidak tersedia. Mohon coba beberapa saat lagi.',
            ]);
        }

        $data = $apiResult['data'];
        $label = $data['label'] ?? 'Tidak Valid';
        $confidence = $data['confidence'] ?? 0.0;
        $probPositif = $data['prob_positif'] ?? 0.0;
        $probNegatif = $data['prob_negatif'] ?? 0.0;
        $cleanText = $data['clean_text'] ?? '';
        $topWords = $data['top_words'] ?? [];
        $statusType = $data['status'] ?? 'valid';

        // Jika teks tidak valid / gibberish: JANGAN simpan ke database
        if ($label === 'Tidak Valid' || $statusType === 'invalid') {
            return $this->response->setJSON([
                'success'      => true,
                'is_invalid'   => true,
                'label'        => 'Tidak Valid',
                'confidence'   => 0.0,
                'prob_positif' => 0.0,
                'prob_negatif' => 0.0,
                'category'     => null,
                'clean_text'   => '',
                'top_words'    => [],
                'text'         => $text,
                'message'      => $data['message'] ?? 'Teks tidak dapat dianalisis. Mohon masukkan ulasan yang jelas.',
                'reason'       => $data['reason'] ?? '',
            ]);
        }

        // Kategori keluhan (hanya untuk sentimen Negatif)
        $category = null;
        if ($label === 'Negatif') {
            if (!empty($data['category'])) {
                $category = $data['category'];
            } else {
                $category = ComplaintCategorizer::categorize($text, $cleanText);
            }
        }

        // Simpan ke database (hanya untuk prediksi valid)
        try {
            $insertId = $this->predictionModel->insert([
                'text_original' => $text,
                'text_clean'    => $cleanText,
                'label'         => $label,
                'confidence'    => $confidence,
                'prob_positif'  => $probPositif,
                'prob_negatif'  => $probNegatif,
                'top_words'     => json_encode($topWords),
                'category'      => $category,
                'source'        => 'single',
                'created_at'    => date('Y-m-d H:i:s'),
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Gagal menyimpan prediksi ke database: ' . $e->getMessage());
            $insertId = null;
        }

        return $this->response->setJSON([
            'success'      => true,
            'is_invalid'   => false,
            'id'           => $insertId,
            'text'         => $text,
            'clean_text'   => $cleanText,
            'label'        => $label,
            'confidence'   => $confidence,
            'prob_positif' => $probPositif,
            'prob_negatif' => $probNegatif,
            'category'     => $category,
            'top_words'    => $topWords,
        ]);
    }
}
