<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Tentang extends Controller
{
    public function index()
    {
        return view('tentang/index', [
            'title' => 'Tentang Project - SatuSehat Sentiment Analyzer'
        ]);
    }
}
