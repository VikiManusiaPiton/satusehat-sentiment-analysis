<?php

namespace App\Controllers;

use App\Libraries\SentimentClient;
use CodeIgniter\Controller;

class Performa extends Controller
{
    protected SentimentClient $client;

    public function __construct()
    {
        $this->client = new SentimentClient();
    }

    public function index()
    {
        $metricsResponse = $this->client->getMetrics();
        $metricsData = null;
        $fromCache = false;

        if ($metricsResponse['success']) {
            $metricsData = $metricsResponse['data'];
        } else {
            // Fallback membaca langsung dari file lokal jika API belum running
            $localFile = FCPATH . '../sentiment-api/model/metrics.json';
            if (file_exists($localFile)) {
                $content = file_get_contents($localFile);
                $metricsData = json_decode($content, true);
                $fromCache = true;
            }
        }

        return view('performa/index', [
            'title'       => 'Performa & Evaluasi Model Machine Learning',
            'metrics'     => $metricsData,
            'apiOnline'   => $metricsResponse['success'],
            'fromCache'   => $fromCache,
            'errorMessage'=> !$metricsData ? ($metricsResponse['message'] ?? 'Data metrik belum tersedia.') : null,
        ]);
    }
}
