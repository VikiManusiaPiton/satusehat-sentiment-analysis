<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class Auth extends Controller
{
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/login', [
            'title' => 'Login Admin - SatuSehat Sentiment Analyzer'
        ]);
    }

    public function attemptLogin()
    {
        $rules = [
            'username' => 'required|trim',
            'password' => 'required|min_length[4]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Silakan masukkan username dan password yang valid.');
        }

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            return redirect()->back()->withInput()->with('error', 'Kombinasi username atau password salah.');
        }

        // Set session
        session()->set([
            'isLoggedIn' => true,
            'userId'     => $user['id'],
            'username'   => $user['username'],
        ]);

        return redirect()->to('/dashboard')->with('success', 'Selamat datang kembali, ' . esc($user['username']) . '!');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/analisis')->with('success', 'Anda telah berhasil logout.');
    }
}
