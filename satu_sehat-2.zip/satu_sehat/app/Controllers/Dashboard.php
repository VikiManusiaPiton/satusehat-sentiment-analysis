<?php

namespace App\Controllers;

use App\Models\PredictionModel;
use App\Libraries\SentimentClient;
use CodeIgniter\Controller;

class Dashboard extends Controller
{
    protected PredictionModel $predictionModel;
    protected SentimentClient $sentimentClient;

    public function __construct()
    {
        $this->predictionModel = new PredictionModel();
        $this->sentimentClient = new SentimentClient();
    }

    public function index()
    {
        // 1. KPI cards
        $stats = $this->predictionModel->getSummaryStats();

        // 2. Data tren harian
        $dailyTrends = $this->predictionModel->getDailyTrend(14);

        // 3. Keluhan terbanyak (ulasan negatif)
        $topComplaints = $this->predictionModel->getTopComplaints(6);

        // 4. Word cloud / top words untuk positif & negatif
        $topPositiveWords = $this->predictionModel->getTopWordsBySentiment('Positif', 12);
        $topNegativeWords = $this->predictionModel->getTopWordsBySentiment('Negatif', 12);

        // 5. Cek status API
        $apiOnline = $this->sentimentClient->health();

        return view('dashboard/index', [
            'title'            => 'Dashboard Analitik Sentimen SatuSehat',
            'stats'            => $stats,
            'dailyTrends'      => $dailyTrends,
            'topComplaints'    => $topComplaints,
            'topPositiveWords' => $topPositiveWords,
            'topNegativeWords' => $topNegativeWords,
            'apiOnline'        => $apiOnline,
        ]);
    }
}
