<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateAppTables extends Migration
{
    public function up()
    {
        // 1. Tabel users
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'username' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
                'unique'     => true,
            ],
            'password_hash' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('users', true);

        // 2. Tabel predictions
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'text_original' => [
                'type' => 'TEXT',
            ],
            'text_clean' => [
                'type' => 'TEXT',
            ],
            'label' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
            ],
            'confidence' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,4',
            ],
            'prob_positif' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,4',
            ],
            'prob_negatif' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,4',
            ],
            'top_words' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'category' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
                'null'       => true,
            ],
            'source' => [
                'type'       => 'ENUM',
                'constraint' => ['single', 'batch'],
                'default'    => 'single',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('label');
        $this->forge->addKey('category');
        $this->forge->addKey('created_at');
        $this->forge->createTable('predictions', true);

        // 3. Tabel batch_uploads
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'filename' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'total_rows' => [
                'type'       => 'INT',
                'constraint' => 11,
                'default'    => 0,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('batch_uploads', true);
    }

    public function down()
    {
        $this->forge->dropTable('batch_uploads', true);
        $this->forge->dropTable('predictions', true);
        $this->forge->dropTable('users', true);
    }
}
