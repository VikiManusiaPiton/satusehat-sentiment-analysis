<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SamplePredictionSeeder extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('predictions');

        // Jika tabel masih kosong, masukkan beberapa sampel data realistis
        if ($builder->countAllResults() === 0) {
            $samples = [
                [
                    'text_original' => 'Sertifikat vaksin ketiga booster belum muncul juga di aplikasi padahal mau buat syarat naik pesawat',
                    'text_clean'    => 'sertifikat vaksin tiga booster belum muncul aplikasi padahal buat syarat naik pesawat',
                    'label'         => 'Negatif',
                    'confidence'    => 0.8845,
                    'prob_positif'  => 0.1155,
                    'prob_negatif'  => 0.8845,
                    'top_words'     => json_encode([['word' => 'sertifikat', 'weight' => -0.85], ['word' => 'vaksin', 'weight' => -0.62], ['word' => 'muncul', 'weight' => -0.74]]),
                    'category'      => 'Sertifikat vaksin tidak muncul',
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-4 days')),
                ],
                [
                    'text_original' => 'Kode OTP verifikasi nomor whatsapp dan sms tidak pernah masuk, tolong respon min',
                    'text_clean'    => 'kode otp verifikasi nomor whatsapp sms tidak pernah masuk tolong respon min',
                    'label'         => 'Negatif',
                    'confidence'    => 0.9230,
                    'prob_positif'  => 0.0770,
                    'prob_negatif'  => 0.9230,
                    'top_words'     => json_encode([['word' => 'otp', 'weight' => -1.35], ['word' => 'verifikasi', 'weight' => -0.75], ['word' => 'masuk', 'weight' => -0.55]]),
                    'category'      => 'OTP/verifikasi',
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-3 days')),
                ],
                [
                    'text_original' => 'Aplikasi sangat bagus dan memudahkan saya cek jadwal imunisasi anak dan faskes terdekat',
                    'text_clean'    => 'aplikasi bagus mudah saya cek jadwal imunisasi anak faskes dekat',
                    'label'         => 'Positif',
                    'confidence'    => 0.9412,
                    'prob_positif'  => 0.9412,
                    'prob_negatif'  => 0.0588,
                    'top_words'     => json_encode([['word' => 'bagus', 'weight' => 0.82], ['word' => 'mudah', 'weight' => 0.78], ['word' => 'jadwal', 'weight' => 0.45]]),
                    'category'      => null,
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-3 days')),
                ],
                [
                    'text_original' => 'Aplikasi lemot banget sering macet dan error force close waktu mau scan barcode masuk gedung',
                    'text_clean'    => 'aplikasi lemot sering macet error force close waktu mau scan barcode masuk gedung',
                    'label'         => 'Negatif',
                    'confidence'    => 0.9520,
                    'prob_positif'  => 0.0480,
                    'prob_negatif'  => 0.9520,
                    'top_words'     => json_encode([['word' => 'lemot', 'weight' => -1.15], ['word' => 'error', 'weight' => -1.05], ['word' => 'force close', 'weight' => -0.88]]),
                    'category'      => 'Performa/error',
                    'source'        => 'batch',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-2 days')),
                ],
                [
                    'text_original' => 'Tidak bisa input tanggal lahir anak, format error terus padahal NIK sudah benar',
                    'text_clean'    => 'tidak bisa input tanggal lahir anak format error padahal nik benar',
                    'label'         => 'Negatif',
                    'confidence'    => 0.8920,
                    'prob_positif'  => 0.1080,
                    'prob_negatif'  => 0.8920,
                    'top_words'     => json_encode([['word' => 'tanggal lahir', 'weight' => -0.92], ['word' => 'nik', 'weight' => -0.71], ['word' => 'tidak bisa', 'weight' => -0.85]]),
                    'category'      => 'Input data/tanggal lahir',
                    'source'        => 'batch',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-2 days')),
                ],
                [
                    'text_original' => 'Scan QR barcode puskesmas selalu bilang di luar radius lokasi padahal sudah berdiri di depan loket',
                    'text_clean'    => 'scan qr barcode puskesmas selalu bilang luar radius lokasi padahal berdiri depan loket',
                    'label'         => 'Negatif',
                    'confidence'    => 0.8750,
                    'prob_positif'  => 0.1250,
                    'prob_negatif'  => 0.8750,
                    'top_words'     => json_encode([['word' => 'radius', 'weight' => -0.90], ['word' => 'lokasi', 'weight' => -0.78], ['word' => 'scan', 'weight' => -0.65]]),
                    'category'      => 'Lokasi/scan QR',
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-1 days')),
                ],
                [
                    'text_original' => 'Mau login selalu gagal padahal password benar, registrasi ulang juga mental ke beranda',
                    'text_clean'    => 'mau login selalu gagal padahal password benar registrasi ulang mental beranda',
                    'label'         => 'Negatif',
                    'confidence'    => 0.9140,
                    'prob_positif'  => 0.0860,
                    'prob_negatif'  => 0.9140,
                    'top_words'     => json_encode([['word' => 'login', 'weight' => -0.98], ['word' => 'gagal', 'weight' => -1.12], ['word' => 'registrasi', 'weight' => -0.74]]),
                    'category'      => 'Login/registrasi',
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s', strtotime('-1 days')),
                ],
                [
                    'text_original' => 'Mantap sekali fiturnya lengkap, riwayat vaksin langsung sinkron dengan KTP, terima kasih',
                    'text_clean'    => 'mantap sekali fitur lengkap riwayat vaksin langsung sinkron ktp terima kasih',
                    'label'         => 'Positif',
                    'confidence'    => 0.9620,
                    'prob_positif'  => 0.9620,
                    'prob_negatif'  => 0.0380,
                    'top_words'     => json_encode([['word' => 'mantap', 'weight' => 0.94], ['word' => 'terima kasih', 'weight' => 0.89], ['word' => 'lengkap', 'weight' => 0.65]]),
                    'category'      => null,
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s'),
                ],
                [
                    'text_original' => 'Desain tampilan semakin fresh dan ringan saat dibuka, tidak ada lag sama sekali',
                    'text_clean'    => 'desain tampil makin fresh ringan buka tidak lag sama sekali',
                    'label'         => 'Positif',
                    'confidence'    => 0.9150,
                    'prob_positif'  => 0.9150,
                    'prob_negatif'  => 0.0850,
                    'top_words'     => json_encode([['word' => 'ringan', 'weight' => 0.75], ['word' => 'fresh', 'weight' => 0.70], ['word' => 'desain', 'weight' => 0.42]]),
                    'category'      => null,
                    'source'        => 'single',
                    'created_at'    => date('Y-m-d H:i:s'),
                ]
            ];

            $builder->insertBatch($samples);
        }
    }
}
