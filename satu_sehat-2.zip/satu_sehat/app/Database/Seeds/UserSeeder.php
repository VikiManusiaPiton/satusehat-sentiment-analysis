<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('users');

        // Cek jika admin sudah ada
        $existing = $builder->where('username', 'admin')->get()->getRow();
        if (!$existing) {
            $builder->insert([
                'username'      => 'admin',
                'password_hash' => password_hash('admin123', PASSWORD_BCRYPT),
                'created_at'    => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
