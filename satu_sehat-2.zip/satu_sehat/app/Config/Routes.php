<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Route Publik
$routes->get('/', 'Analisis::index');
$routes->get('/analisis', 'Analisis::index');
$routes->post('/analisis/prediksi', 'Analisis::prediksi');
$routes->get('/tentang', 'Tentang::index');

// Autentikasi
$routes->get('/auth/login', 'Auth::login');
$routes->post('/auth/login', 'Auth::attemptLogin');
$routes->get('/auth/logout', 'Auth::logout');

// Route Terproteksi (Admin Area)
$routes->group('', ['filter' => 'auth'], function ($routes) {
    // Dashboard
    $routes->get('/dashboard', 'Dashboard::index');

    // Riwayat
    $routes->get('/riwayat', 'Riwayat::index');
    $routes->get('/riwayat/delete/(:num)', 'Riwayat::delete/$1');
    $routes->post('/riwayat/clear', 'Riwayat::clearAll');

    // Performa Model
    $routes->get('/performa', 'Performa::index');

    // Batch Upload CSV
    $routes->get('/batch', 'Batch::index');
    $routes->post('/batch/upload', 'Batch::upload');
    $routes->get('/batch/download', 'Batch::download');
    $routes->get('/batch/download/(:num)', 'Batch::download/$1');
    $routes->get('/batch/sample', 'Batch::sampleCsv');
});
