<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-file-earmark-spreadsheet text-primary me-2"></i> Prediksi Sentimen Massal (Upload CSV)
        </h3>
        <p class="text-secondary small mb-0">Unggah berkas CSV ulasan SATUSEHAT untuk diklasifikasikan secara massal menggunakan endpoint batch processing.</p>
    </div>
    <div>
        <a href="<?= base_url('/batch/sample') ?>" class="btn btn-outline-secondary btn-sm rounded-pill px-3">
            <i class="bi bi-download me-1"></i> Unduh Contoh / Template CSV
        </a>
    </div>
</div>

<!-- Upload Form Card -->
<div class="card mb-4">
    <div class="card-header bg-white py-3">
        <span class="fw-bold text-dark fs-5">
            <i class="bi bi-cloud-arrow-up-fill text-primary me-2"></i> Unggah Berkas CSV
        </span>
    </div>
    <div class="card-body p-4">
        <form action="<?= base_url('/batch/upload') ?>" method="post" enctype="multipart/form-data" id="batchUploadForm">
            <?= csrf_field() ?>

            <div class="row align-items-center g-4">
                <div class="col-lg-7">
                    <div class="p-4 border-2 border-dashed rounded-4 text-center bg-light" style="border: 2px dashed #cbd5e1;">
                        <i class="bi bi-filetype-csv text-primary display-4 mb-3 d-block"></i>
                        <label for="csvFileInput" class="form-label fw-bold text-dark mb-1 fs-6">Pilih Berkas CSV dari Komputer</label>
                        <p class="text-muted small mb-3">Format yang didukung: .csv (Maksimal 5 MB / 5.000 baris)</p>
                        <input class="form-control" type="file" id="csvFileInput" name="csv_file" accept=".csv,text/csv" required>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="card bg-light border-0">
                        <div class="card-body p-3">
                            <h6 class="fw-bold text-dark mb-2">
                                <i class="bi bi-info-circle-fill text-info me-1"></i> Ketentuan Berkas CSV:
                            </h6>
                            <ul class="small text-secondary mb-3 ps-3">
                                <li>Wajib memiliki kolom bernama <strong><code>content</code></strong> pada baris pertama (header).</li>
                                <li>Mendukung pemisah kolom koma (<code>,</code>) maupun titik koma (<code>;</code>).</li>
                                <li>Maksimal <strong>5.000 baris</strong> per unggahan berkas.</li>
                                <li>Sistem membagi request ke Python API per 250 baris untuk efisiensi komputasi.</li>
                                <li>Hasil prediksi disimpan otomatis ke riwayat database.</li>
                            </ul>
                            <button type="submit" id="btnUploadSubmit" class="btn btn-primary w-100 py-2 rounded-pill fw-semibold shadow-sm">
                                <span id="btnUploadSpinner" class="spinner-border spinner-border-sm me-2 d-none" role="status"></span>
                                <i id="btnUploadIcon" class="bi bi-lightning-charge-fill me-1"></i> Proses Prediksi Massal
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Hasil Prediksi Batch Terakhir (Preview) -->
<?php if (!empty($previewResults)): ?>
<div class="card mb-4 border-top border-4 border-success">
    <div class="card-header bg-white py-3 d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">
        <div>
            <span class="fw-bold text-dark fs-5">
                <i class="bi bi-check-circle-fill text-success me-2"></i> Hasil Prediksi Berkas: <?= esc($batchInfo['filename'] ?? 'Upload CSV') ?>
            </span>
            <div class="text-muted small">
                Total: <strong><?= number_format($batchInfo['total_rows'] ?? count($previewResults)) ?></strong> baris ulasan berhasil diproses.
                <?php if (isset($batchInfo['total_rows']) && $batchInfo['total_rows'] > count($previewResults)): ?>
                    <span class="text-primary">(Menampilkan <?= count($previewResults) ?> baris preview pertama, unduh CSV untuk seluruh data)</span>
                <?php endif; ?>
            </div>
        </div>
        <div>
            <a href="<?= base_url('/batch/download/' . ($batchInfo['id'] ?? '')) ?>" class="btn btn-success rounded-pill px-4 btn-sm shadow-sm">
                <i class="bi bi-file-earmark-arrow-down-fill me-1"></i> Unduh CSV Hasil
            </a>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;" class="text-center">#</th>
                        <th>Teks Ulasan (Content)</th>
                        <th style="width: 120px;" class="text-center">Sentimen</th>
                        <th style="width: 110px;" class="text-center">Confidence</th>
                        <th>Kategori Keluhan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($previewResults as $row): ?>
                        <tr>
                            <td class="text-center text-muted small"><?= $no++ ?></td>
                            <td>
                                <div class="text-dark fw-medium" style="max-width: 480px;">
                                    <?= esc($row['text_original']) ?>
                                </div>
                            </td>
                            <td class="text-center">
                                <?php if ($row['label'] === 'Positif'): ?>
                                    <span class="badge badge-positive px-2 py-1 rounded-pill">
                                        <i class="bi bi-hand-thumbs-up-fill me-1"></i> Positif
                                    </span>
                                <?php elseif ($row['label'] === 'Negatif'): ?>
                                    <span class="badge badge-negative px-2 py-1 rounded-pill">
                                        <i class="bi bi-hand-thumbs-down-fill me-1"></i> Negatif
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary text-white px-2 py-1 rounded-pill">
                                        <i class="bi bi-slash-circle me-1"></i> <?= esc($row['label']) ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if ($row['label'] === 'Tidak Valid' || (float)$row['confidence'] == 0): ?>
                                    <span class="text-muted small">-</span>
                                <?php else: ?>
                                    <span class="fw-bold font-monospace"><?= round((float)$row['confidence'] * 100, 1) ?>%</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($row['label'] === 'Tidak Valid'): ?>
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary-subtle small">
                                        Teks Tidak Valid
                                    </span>
                                <?php elseif (!empty($row['category'])): ?>
                                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger-subtle small">
                                        <?= esc($row['category']) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?= $this->section('scripts') ?>
<script>
    const form = document.getElementById('batchUploadForm');
    const btn = document.getElementById('btnUploadSubmit');
    const spinner = document.getElementById('btnUploadSpinner');
    const icon = document.getElementById('btnUploadIcon');

    form.addEventListener('submit', function() {
        btn.disabled = true;
        spinner.classList.remove('d-none');
        icon.classList.add('d-none');
    });
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>
