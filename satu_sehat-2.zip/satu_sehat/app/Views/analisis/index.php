<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Header Banner -->
        <div class="card border-0 mb-4 text-white shadow" style="background: linear-gradient(135deg, #0284c7 0%, #0d9488 100%);">
            <div class="card-body p-4 p-md-5">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <span class="badge bg-white text-primary fw-semibold px-3 py-2 rounded-pill mb-2">
                            <i class="bi bi-robot me-1"></i> NLP Logistic Regression + TF-IDF
                        </span>
                        <h2 class="fw-bold mb-2">Analisis Sentimen Ulasan SATUSEHAT</h2>
                        <p class="mb-0 text-white-50 fs-6">
                            Klasifikasi otomatis ulasan pengguna Google Play Store menjadi sentimen Positif atau Negatif lengkap dengan skor confidence, ekstraksi kata kunci penentu, dan deteksi kategori keluhan.
                        </p>
                    </div>
                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                        <div class="d-inline-flex align-items-center gap-2 bg-white bg-opacity-25 px-3 py-2 rounded-pill text-white small">
                            <span class="spinner-grow spinner-grow-sm text-light" role="status"></span>
                            <span>Model Service: <strong>FastAPI :5000</strong></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Input Ulasan -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <div class="fw-bold text-dark fs-5">
                    <i class="bi bi-pencil-square text-primary me-2"></i> Masukkan Teks Ulasan
                </div>
                <div class="d-flex gap-1">
                    <button type="button" class="btn btn-sm btn-outline-success rounded-pill px-3" onclick="fillExample('pos')">
                        <i class="bi bi-hand-thumbs-up me-1"></i> Contoh Positif
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-3" onclick="fillExample('neg')">
                        <i class="bi bi-hand-thumbs-down me-1"></i> Contoh Negatif
                    </button>
                </div>
            </div>
            <div class="card-body p-4">
                <form id="sentimentForm" onsubmit="event.preventDefault(); analyzeSentiment();">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <textarea class="form-control form-control-lg fs-6" id="reviewText" name="text" rows="4" maxlength="1000" placeholder="Ketik atau tempel ulasan pengguna aplikasi SATUSEHAT di sini... (Contoh: Kode OTP verifikasi tidak kunjung masuk ke sms dan email)"></textarea>
                        <div class="d-flex justify-content-between align-items-center mt-2 small text-muted">
                            <span><i class="bi bi-info-circle me-1"></i> Maksimal 1.000 karakter.</span>
                            <span id="charCounter">0 / 1000</span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-light text-secondary rounded-pill px-3" onclick="resetForm()">
                            <i class="bi bi-arrow-counterclockwise me-1"></i> Bersihkan
                        </button>
                        <button type="submit" id="btnAnalyze" class="btn btn-primary px-4 py-2 rounded-pill fw-semibold shadow-sm">
                            <span id="btnSpinner" class="spinner-border spinner-border-sm me-2 d-none" role="status"></span>
                            <i id="btnIcon" class="bi bi-send-fill me-1"></i> Analisis Sentimen
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Alert Error Container -->
        <div id="errorAlert" class="alert alert-danger d-none shadow-sm rounded-3 mb-4" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2 fs-5 align-middle"></i>
            <span id="errorMessage"></span>
        </div>

        <!-- Result Container -->
        <div id="resultContainer" class="d-none">
            <div class="card mb-4 border-top border-4" id="resultCardBorder">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <div class="fw-bold text-dark fs-5">
                        <i class="bi bi-speedometer2 text-primary me-2"></i> Hasil Analisis Prediksi
                    </div>
                    <span id="resultBadge" class="badge px-3 py-2 fs-6 rounded-pill"></span>
                </div>
                <div class="card-body p-4">
                    <!-- Alert Khusus Teks Tidak Valid -->
                    <div id="invalidAlertBox" class="alert alert-warning border-warning d-none mb-4 d-flex align-items-center gap-3 shadow-sm rounded-3">
                        <i class="bi bi-exclamation-triangle-fill fs-3 text-warning flex-shrink-0"></i>
                        <div>
                            <div class="fw-bold fs-6 text-dark" id="invalidMainMsg">Teks tidak dapat dianalisis. Mohon masukkan ulasan yang jelas.</div>
                            <div id="invalidReasonText" class="small text-muted mt-1"></div>
                        </div>
                    </div>

                    <div class="row g-4 mb-4">
                        <!-- Confidence Score Bar -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-secondary small text-uppercase mb-1">Tingkat Keyakinan (Confidence)</label>
                            <div class="d-flex align-items-baseline justify-content-between mb-1">
                                <span id="confPercentage" class="fs-3 fw-bold text-dark">0%</span>
                                <span id="confLabelText" class="small fw-semibold text-muted"></span>
                            </div>
                            <div class="progress" style="height: 12px; border-radius: 6px;">
                                <div id="confProgressBar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%;"></div>
                            </div>
                            <div class="d-flex justify-content-between text-muted small mt-2">
                                <span>P(Negatif): <strong id="probNegVal">0%</strong></span>
                                <span>P(Positif): <strong id="probPosVal">0%</strong></span>
                            </div>
                        </div>

                        <!-- Kategori Keluhan & Info -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-secondary small text-uppercase mb-1">Kategori Keluhan (Khusus Negatif)</label>
                            <div id="categoryWrapper" class="p-3 rounded-3 bg-light border">
                                <div id="categoryContent" class="fw-bold fs-6 text-danger">
                                    <i class="bi bi-tag-fill me-1"></i> <span id="categoryName">-</span>
                                </div>
                                <div id="categoryDesc" class="small text-muted mt-1">
                                    Terdeteksi berdasarkan kata kunci keluhan pengguna SATUSEHAT.
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Highlighted Text Input -->
                    <div class="mb-4">
                        <label class="form-label fw-bold text-secondary small text-uppercase mb-1">
                            <i class="bi bi-highlighter me-1"></i> Teks Ulasan dengan Highlight Kata Berpengaruh
                        </label>
                        <div class="p-3 rounded-3 bg-light border lh-lg fs-6" id="highlightedReview">
                            <!-- Populated by JS -->
                        </div>
                        <div class="mt-2 small text-muted d-flex gap-3">
                            <span><span class="badge" style="background-color: #bbf7d0; color: #065f46;">Hijau</span> = Mendorong ke Positif</span>
                            <span><span class="badge" style="background-color: #fecaca; color: #991b1b;">Merah</span> = Mendorong ke Negatif</span>
                        </div>
                    </div>

                    <!-- Kata Berpengaruh (Explainability Table) -->
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="form-label fw-bold text-secondary small text-uppercase mb-0">
                                <i class="bi bi-lightbulb-fill text-warning me-1"></i> Kata Kunci Berpengaruh (Explainability Model)
                            </label>
                            <span class="small text-muted">Dihitung dari koefisien model ($w_i = \text{coef}_i \times \text{tfidf}_i$)</span>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-sm table-hover align-middle border mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Kata Kunci</th>
                                        <th>Nilai Bobot (Weight)</th>
                                        <th>Arah Kontribusi</th>
                                    </tr>
                                </thead>
                                <tbody id="topWordsTbody">
                                    <!-- Populated by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?= $this->section('scripts') ?>
<script>
    const samplePos = "Aplikasi SatuSehat sangat bagus dan memudahkan saya cek sertifikat vaksin dan imunisasi anak. Pelayanan responsif dan lancar jaya!";
    const sampleNeg = "Kode OTP verifikasi tidak masuk masuk ke sms dan email, aplikasi error terus dan lemot saat mau login!";

    const reviewText = document.getElementById('reviewText');
    const charCounter = document.getElementById('charCounter');
    const btnAnalyze = document.getElementById('btnAnalyze');
    const btnSpinner = document.getElementById('btnSpinner');
    const btnIcon = document.getElementById('btnIcon');
    const errorAlert = document.getElementById('errorAlert');
    const errorMessage = document.getElementById('errorMessage');
    const resultContainer = document.getElementById('resultContainer');

    reviewText.addEventListener('input', function() {
        charCounter.textContent = `${this.value.length} / 1000`;
    });

    function fillExample(type) {
        reviewText.value = (type === 'pos') ? samplePos : sampleNeg;
        charCounter.textContent = `${reviewText.value.length} / 1000`;
        reviewText.focus();
    }

    function resetForm() {
        reviewText.value = '';
        charCounter.textContent = '0 / 1000';
        resultContainer.classList.add('d-none');
        errorAlert.classList.add('d-none');
    }

    async function analyzeSentiment() {
        const text = reviewText.value.trim();
        if (!text) {
            showError("Silakan ketik atau tempel ulasan terlebih dahulu.");
            return;
        }

        // Reset state
        errorAlert.classList.add('d-none');
        btnAnalyze.disabled = true;
        btnSpinner.classList.remove('d-none');
        btnIcon.classList.add('d-none');

        try {
            const formData = new FormData();
            formData.append('text', text);

            const response = await fetch('<?= base_url('/analisis/prediksi') ?>', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: formData
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.message || 'Layanan analisis sedang tidak tersedia. Mohon coba beberapa saat lagi.');
            }

            renderResult(data);
        } catch (err) {
            showError(err.message || 'Layanan analisis sedang tidak tersedia.');
            resultContainer.classList.add('d-none');
        } finally {
            btnAnalyze.disabled = false;
            btnSpinner.classList.add('d-none');
            btnIcon.classList.remove('d-none');
        }
    }

    function showError(msg) {
        errorMessage.textContent = msg;
        errorAlert.classList.remove('d-none');
    }

    function renderResult(data) {
        resultContainer.classList.remove('d-none');

        const isInvalid = data.label === 'Tidak Valid' || data.is_invalid;
        const isPos = data.label === 'Positif';
        const invalidAlertBox = document.getElementById('invalidAlertBox');
        const invalidReasonText = document.getElementById('invalidReasonText');
        const badge = document.getElementById('resultBadge');
        const cardBorder = document.getElementById('resultCardBorder');
        const progressBar = document.getElementById('confProgressBar');
        const confPercentage = document.getElementById('confPercentage');
        const confLabelText = document.getElementById('confLabelText');
        const probPosVal = document.getElementById('probPosVal');
        const probNegVal = document.getElementById('probNegVal');
        const categoryWrapper = document.getElementById('categoryWrapper');
        const categoryName = document.getElementById('categoryName');
        const categoryDesc = document.getElementById('categoryDesc');

        if (isInvalid) {
            // Tampilan Khusus Teks Tidak Valid / Gibberish
            invalidAlertBox.classList.remove('d-none');
            invalidReasonText.textContent = data.reason ? `Detail validasi: ${data.reason}` : 'Teks berupa karakter acak, kurang dari 3 huruf alfabet, deret konsonan/vokal berulang, atau tidak ada dalam kamus.';
            
            badge.className = 'badge bg-secondary text-white px-3 py-2 fs-6 rounded-pill';
            badge.innerHTML = '<i class="bi bi-slash-circle me-1"></i> Tidak Valid';
            cardBorder.className = 'card mb-4 border-top border-4 border-secondary';
            
            progressBar.className = 'progress-bar bg-secondary';
            progressBar.style.width = '0%';
            confPercentage.textContent = '0%';
            confLabelText.textContent = 'Tidak Valid, 0%';
            
            probPosVal.textContent = '0%';
            probNegVal.textContent = '0%';

            categoryWrapper.className = 'p-3 rounded-3 bg-secondary bg-opacity-10 border border-secondary-subtle';
            categoryName.textContent = 'Teks Tidak Valid';
            categoryName.className = 'fw-bold fs-6 text-secondary';
            categoryDesc.textContent = 'Teks ulasan tidak memenuhi kriteria validasi bahasa atau merupakan karakter acak/gibberish.';

            const tbody = document.getElementById('topWordsTbody');
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-3"><i class="bi bi-shield-x me-1 text-warning"></i> Model sentimen diabaikan karena teks terdeteksi tidak valid / gibberish. Tidak disimpan ke riwayat database.</td></tr>';

            const container = document.getElementById('highlightedReview');
            container.textContent = data.text;

            resultContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            return;
        }

        // Teks Valid (Positif / Negatif)
        invalidAlertBox.classList.add('d-none');

        // Badge & Styles
        if (isPos) {
            badge.className = 'badge badge-positive px-3 py-2 fs-6 rounded-pill';
            badge.innerHTML = '<i class="bi bi-hand-thumbs-up-fill me-1"></i> Positif';
            cardBorder.className = 'card mb-4 border-top border-4 border-success';
            progressBar.className = 'progress-bar bg-success progress-bar-striped progress-bar-animated';
        } else {
            badge.className = 'badge badge-negative px-3 py-2 fs-6 rounded-pill';
            badge.innerHTML = '<i class="bi bi-hand-thumbs-down-fill me-1"></i> Negatif';
            cardBorder.className = 'card mb-4 border-top border-4 border-danger';
            progressBar.className = 'progress-bar bg-danger progress-bar-striped progress-bar-animated';
        }

        // Confidence
        const confPct = Math.round(data.confidence * 100);
        confPercentage.textContent = `${confPct}%`;
        confLabelText.textContent = `${data.label}, ${confPct}%`;
        progressBar.style.width = `${confPct}%`;

        probPosVal.textContent = `${Math.round(data.prob_positif * 100)}%`;
        probNegVal.textContent = `${Math.round(data.prob_negatif * 100)}%`;

        // Kategori Keluhan
        if (data.category) {
            categoryWrapper.className = 'p-3 rounded-3 bg-danger bg-opacity-10 border border-danger-subtle';
            categoryName.className = 'fw-bold fs-6 text-danger';
            categoryName.textContent = data.category;
            if (data.category === 'Mengandung kata kasar') {
                categoryDesc.textContent = 'Terdeteksi mengandung kata kasar/profanity bahasa Indonesia. Model sentimen otomatis menetapkan label Negatif.';
            } else {
                categoryDesc.textContent = 'Kategori masalah teridentifikasi pada ulasan negatif pengguna.';
            }
        } else {
            categoryWrapper.className = 'p-3 rounded-3 bg-light border';
            categoryName.textContent = 'Tidak ada keluhan (Sentimen Positif)';
            categoryName.className = 'fw-semibold text-muted';
            categoryDesc.textContent = 'Ulasan ini bermuatan positif terhadap pengalaman aplikasi SATUSEHAT.';
        }

        // Explainability Top Words Table
        const tbody = document.getElementById('topWordsTbody');
        tbody.innerHTML = '';

        if (!data.top_words || data.top_words.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-3">Tidak ada kata kunci spesifik yang terdaftar dalam kamus model.</td></tr>';
        } else {
            data.top_words.forEach((item, index) => {
                const tr = document.createElement('tr');
                const isWordPos = item.weight > 0;
                tr.innerHTML = `
                    <td>${index + 1}</td>
                    <td><strong class="font-monospace">${escapeHtml(item.word)}</strong></td>
                    <td class="font-monospace fw-semibold ${isWordPos ? 'text-success' : 'text-danger'}">${item.weight > 0 ? '+' : ''}${item.weight.toFixed(4)}</td>
                    <td>
                        <span class="badge ${isWordPos ? 'badge-positive' : 'badge-negative'}">
                            ${isWordPos ? '<i class="bi bi-arrow-up-right me-1"></i> Dorong Positif' : '<i class="bi bi-arrow-down-right me-1"></i> Dorong Negatif'}
                        </span>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        // Highlighted text
        highlightText(data.text, data.top_words || []);

        // Scroll to results
        resultContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function highlightText(text, topWords) {
        const container = document.getElementById('highlightedReview');
        if (!topWords || topWords.length === 0) {
            container.textContent = text;
            return;
        }

        // Buat map kata dan bobotnya
        const wordWeightMap = {};
        topWords.forEach(tw => {
            wordWeightMap[tw.word.toLowerCase()] = tw.weight;
        });

        // Urutkan kata dari yang paling panjang (agar n-gram/frasa didahulukan dari 1 kata)
        const sortedWords = Object.keys(wordWeightMap).sort((a, b) => b.length - a.length);

        let highlighted = escapeHtml(text);

        sortedWords.forEach(w => {
            if (w.trim() === '') return;
            const weight = wordWeightMap[w];
            const cls = weight > 0 ? 'highlight-pos' : 'highlight-neg';
            const title = `${weight > 0 ? 'Mendorong Positif' : 'Mendorong Negatif'} (${weight > 0 ? '+' : ''}${weight.toFixed(2)})`;
            
            // Regex case-insensitive dengan word boundary jika memungkinkan
            const regex = new RegExp(`\\b(${escapeRegex(w)})\\b`, 'gi');
            highlighted = highlighted.replace(regex, `<span class="${cls}" title="${title}">$1</span>`);
        });

        container.innerHTML = highlighted;
    }

    function escapeHtml(str) {
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>
