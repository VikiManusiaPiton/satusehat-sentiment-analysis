<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-clock-history text-primary me-2"></i> Riwayat Prediksi Sentimen
        </h3>
        <p class="text-secondary small mb-0">Daftar ulasan yang telah dianalisis oleh sistem, dilengkapi fitur filter, pencarian, dan manajemen data.</p>
    </div>
    <div class="d-flex gap-2">
        <?php if (!empty($predictions)): ?>
        <button type="button" class="btn btn-outline-danger btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#clearAllModal">
            <i class="bi bi-trash3 me-1"></i> Kosongkan Riwayat
        </button>
        <?php endif; ?>
    </div>
</div>

<!-- Filter & Search Card -->
<div class="card mb-4">
    <div class="card-body p-3">
        <form action="<?= base_url('/riwayat') ?>" method="get" class="row g-2 align-items-end">
            <!-- Keyword Search -->
            <div class="col-md-4">
                <label class="form-label small text-muted fw-semibold mb-1">Pencarian Kata Kunci</label>
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" name="q" class="form-control" placeholder="Cari teks ulasan / keluhan..." value="<?= esc($keyword ?? '') ?>">
                </div>
            </div>

            <!-- Filter Label -->
            <div class="col-md-2 col-6">
                <label class="form-label small text-muted fw-semibold mb-1">Label Sentimen</label>
                <select name="label" class="form-select form-select-sm">
                    <option value="">Semua Label</option>
                    <option value="Positif" <?= ($selectedLabel ?? '') === 'Positif' ? 'selected' : '' ?>>Positif</option>
                    <option value="Negatif" <?= ($selectedLabel ?? '') === 'Negatif' ? 'selected' : '' ?>>Negatif</option>
                </select>
            </div>

            <!-- Filter Tanggal Mulai -->
            <div class="col-md-2 col-6">
                <label class="form-label small text-muted fw-semibold mb-1">Dari Tanggal</label>
                <input type="date" name="start_date" class="form-control form-control-sm" value="<?= esc($startDate ?? '') ?>">
            </div>

            <!-- Filter Tanggal Akhir -->
            <div class="col-md-2 col-6">
                <label class="form-label small text-muted fw-semibold mb-1">Sampai Tanggal</label>
                <input type="date" name="end_date" class="form-control form-control-sm" value="<?= esc($endDate ?? '') ?>">
            </div>

            <!-- Tombol Aksi -->
            <div class="col-md-2 col-6 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm w-100 rounded-pill">
                    <i class="bi bi-funnel-fill me-1"></i> Filter
                </button>
                <a href="<?= base_url('/riwayat') ?>" class="btn btn-light btn-sm rounded-pill text-secondary" title="Reset Filter">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Data Table Card -->
<div class="card mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <span class="fw-bold text-dark">
            <i class="bi bi-table me-2 text-primary"></i> Data Prediksi (Total: <?= number_format($totalCount ?? 0) ?>)
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;" class="text-center">#</th>
                        <th>Teks Ulasan Asli</th>
                        <th style="width: 120px;" class="text-center">Sentimen</th>
                        <th style="width: 110px;" class="text-center">Confidence</th>
                        <th>Kategori Keluhan</th>
                        <th style="width: 100px;" class="text-center">Sumber</th>
                        <th style="width: 130px;">Waktu</th>
                        <th style="width: 70px;" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($predictions)): ?>
                        <?php foreach ($predictions as $row): ?>
                            <tr>
                                <td class="text-center text-muted small"><?= $row['id'] ?></td>
                                <td>
                                    <div class="text-dark fw-medium" style="max-width: 380px;">
                                        <?= esc(function_exists('character_limiter') ? character_limiter($row['text_original'], 95) : mb_strimwidth($row['text_original'], 0, 95, '...')) ?>
                                    </div>
                                    <small class="text-muted fst-italic">
                                        Clean: <?= esc(function_exists('character_limiter') ? character_limiter($row['text_clean'], 70) : mb_strimwidth($row['text_clean'], 0, 70, '...')) ?>
                                    </small>
                                </td>
                                <td class="text-center">
                                    <?php if ($row['label'] === 'Positif'): ?>
                                        <span class="badge badge-positive px-2 py-1 rounded-pill">
                                            <i class="bi bi-hand-thumbs-up-fill me-1"></i> Positif
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-negative px-2 py-1 rounded-pill">
                                            <i class="bi bi-hand-thumbs-down-fill me-1"></i> Negatif
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="fw-bold font-monospace"><?= round($row['confidence'] * 100, 1) ?>%</span>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar <?= $row['label'] === 'Positif' ? 'bg-success' : 'bg-danger' ?>" style="width: <?= round($row['confidence'] * 100) ?>%"></div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($row['category']): ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger border border-danger-subtle small">
                                            <?= esc($row['category']) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary border">
                                        <?= esc($row['source'] ?? 'single') ?>
                                    </span>
                                </td>
                                <td class="small text-muted">
                                    <?= date('d M Y', strtotime($row['created_at'])) ?><br>
                                    <span class="font-monospace text-secondary" style="font-size:0.75rem;"><?= date('H:i:s', strtotime($row['created_at'])) ?></span>
                                </td>
                                <td class="text-center">
                                    <a href="<?= base_url('/riwayat/delete/' . $row['id']) ?>" class="btn btn-outline-danger btn-sm p-1 px-2 rounded-2" onclick="return confirm('Apakah Anda yakin ingin menghapus data ulasan ini?');" title="Hapus Data">
                                        <i class="bi bi-trash3"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                                Tidak ada data riwayat ulasan yang cocok dengan kriteria pencarian.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($pager): ?>
        <div class="card-footer bg-white py-3 d-flex justify-content-center">
            <?= $pager->links('predictions', 'default_full') ?>
        </div>
    <?php endif; ?>
</div>

<!-- Modal Clear All Confirmation -->
<div class="modal fade" id="clearAllModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold text-danger">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> Konfirmasi Kosongkan Riwayat
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3">
                <p class="text-secondary mb-0">
                    Apakah Anda yakin ingin menghapus seluruh data riwayat analisis ulasan? Tindakan ini bersifat permanen dan tidak dapat dibatalkan.
                </p>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Batal</button>
                <form action="<?= base_url('/riwayat/clear') ?>" method="post">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-danger rounded-pill px-4">Ya, Hapus Semua</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
