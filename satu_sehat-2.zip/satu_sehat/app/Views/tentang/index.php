<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Banner Title -->
        <div class="card border-0 mb-4 text-white shadow" style="background: linear-gradient(135deg, #0f766e 0%, #0284c7 100%);">
            <div class="card-body p-4 p-md-5">
                <span class="badge bg-white text-dark fw-semibold px-3 py-2 rounded-pill mb-2">
                    <i class="bi bi-info-circle-fill text-primary me-1"></i> Dokumentasi Project
                </span>
                <h2 class="fw-bold mb-2">Tentang SatuSehat Sentiment Analyzer</h2>
                <p class="mb-0 text-white-50 fs-6">
                    Sistem analisis sentimen berbasis kecerdasan buatan untuk mengevaluasi ulasan masyarakat terhadap aplikasi SATUSEHAT Mobile pada Google Play Store.
                </p>
            </div>
        </div>

        <!-- Deskripsi Project -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-dark fs-5">
                    <i class="bi bi-journal-text text-primary me-2"></i> Deskripsi Proyek
                </span>
            </div>
            <div class="card-body p-4">
                <p class="text-secondary leading-relaxed">
                    <strong>SATUSEHAT Mobile</strong> merupakan aplikasi resmi Kementerian Kesehatan Republik Indonesia yang bertransformasi dari PeduliLindungi sebagai platform integrasi data rekam medis individu dan fasilitas layanan kesehatan di seluruh Indonesia. Keberhasilan adopsi platform ini sangat bergantung pada kepuasan dan respons pengguna.
                </p>
                <p class="text-secondary leading-relaxed mb-0">
                    Aplikasi <strong>SatuSehat Sentiment Analyzer</strong> dibangun untuk memberikan wawasan berbasis data secara real-time terhadap opini publik. Dengan memanfaatkan kombinasi <em>Natural Language Processing (NLP)</em>, arsitektur microservices terpisah (CodeIgniter 4 + Python FastAPI), dan explainability model melalui bobot TF-IDF, sistem ini mampu menyajikan sentimen positif/negatif, confidence score yang akurat, serta mengelompokkan kategori keluhan ulasan secara otomatis.
                </p>
            </div>
        </div>

        <!-- Dataset Information -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <span class="fw-bold text-dark fs-5">
                    <i class="bi bi-database-check text-primary me-2"></i> Informasi Dataset & Sitasi
                </span>
                <span class="badge bg-primary bg-opacity-10 text-primary">Open Science</span>
            </div>
            <div class="card-body p-4">
                <div class="row g-4 align-items-center">
                    <div class="col-md-8">
                        <h5 class="fw-bold text-dark mb-2">Dataset Ulasan SATUSEHAT (Mendeley Data)</h5>
                        <p class="text-secondary small mb-3">
                            Dataset yang digunakan dalam penelitian dan pelatihan model ini bersumber dari repositori riset publik <strong>IGAR Mendeley Data</strong> yang menghimpun ulasan riil pengguna aplikasi SATUSEHAT di Google Play Store.
                        </p>
                        <div class="p-3 bg-light rounded-3 border">
                            <div class="small text-muted mb-1 fw-semibold text-uppercase">Digital Object Identifier (DOI):</div>
                            <div class="fw-bold font-monospace text-primary">
                                <a href="https://doi.org/10.17632/7zryc6k76z.3" target="_blank" rel="noopener noreferrer" class="text-decoration-none">
                                    <i class="bi bi-link-45deg me-1"></i> 10.17632/7zryc6k76z.3
                                </a>
                            </div>
                            <div class="small text-muted mt-2">
                                Sitasi: <em>IGAR SATUSEHAT Mobile Reviews Dataset, Mendeley Data, V3, 2023.</em>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border bg-light text-center p-3">
                            <span class="text-muted small fw-semibold text-uppercase">Total Baris Dataset</span>
                            <h2 class="fw-bold text-primary my-2">3.994</h2>
                            <div class="small text-muted">
                                Distribusi Seimbang (Balanced):<br>
                                <span class="badge badge-positive me-1">1.997 Positif</span>
                                <span class="badge badge-negative">1.997 Negatif</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Metode & Alur Machine Learning -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-dark fs-5">
                    <i class="bi bi-diagram-3-fill text-primary me-2"></i> Metodologi & Arsitektur Sistem
                </span>
            </div>
            <div class="card-body p-4">
                <div class="row g-4">
                    <div class="col-md-6">
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-funnel-fill text-info me-1"></i> 1. Preprocessing Teks (Bahasa Indonesia)</h6>
                        <ul class="small text-secondary ps-3 mb-0">
                            <li><strong>Cleaning:</strong> Menghilangkan URL tautan, mention, hashtag, angka, dan karakter non-alfabet.</li>
                            <li><strong>Case Folding:</strong> Konversi seluruh string teks menjadi huruf kecil (lowercase).</li>
                            <li><strong>Stopword Removal:</strong> Mengeliminasi kata sambung/kata umum memakai kamus PySastrawi.</li>
                            <li><strong>Stemming:</strong> Mengembalikan kata berimbuhan ke bentuk kata dasar menggunakan algoritma Nazief & Adriani melalui library <code>PySastrawi</code>.</li>
                        </ul>
                    </div>

                    <div class="col-md-6">
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-cpu-fill text-success me-1"></i> 2. Ekstraksi Fitur & Klasifikasi</h6>
                        <ul class="small text-secondary ps-3 mb-0">
                            <li><strong>TF-IDF N-Gram (1, 2):</strong> Mengonversi teks ke vektor numerik sekaligus menangkap konteks unigram dan bigram (misal: <em>"tidak bisa"</em>, <em>"force close"</em>).</li>
                            <li><strong>Logistic Regression:</strong> Model klasifikasi probabilistik biner yang menghasilkan estimasi probabilitas $P(\text{Positif})$ dan $P(\text{Negatif})$.</li>
                            <li><strong>Explainability:</strong> Menghitung bobot kontribusi kata $w_i = \text{coef}_i \times \text{tfidf}_i$.</li>
                        </ul>
                    </div>

                    <div class="col-12">
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-hdd-network-fill text-primary me-1"></i> 3. Arsitektur Komunikasi HTTP Terpisah</h6>
                        <p class="small text-secondary mb-0">
                            Web interface dibangun dengan <strong>CodeIgniter 4 (PHP 8.2)</strong> pada port 8080. Seluruh operasi komputasi NLP dan inferensi model dijalankan pada service terpisah menggunakan <strong>FastAPI (Python 3.12)</strong> pada port 5000. Komunikasi antar layer dilakukan secara asynchronous via HTTP REST API berformat JSON dengan timeout 10 detik.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Anggota Kelompok -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-dark fs-5">
                    <i class="bi bi-people-fill text-primary me-2"></i> Anggota Tim Pengembang
                </span>
            </div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="p-3 rounded-3 border bg-light h-100 text-center">
                            <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                <i class="bi bi-person-fill fs-4"></i>
                            </div>
                            <h6 class="fw-bold text-dark mb-0">Vicky Riza Purwanto</h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 rounded-3 border bg-light h-100 text-center">
                            <div class="bg-teal text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px; background-color: #0d9488;">
                                <i class="bi bi-person-fill fs-4"></i>
                            </div>
                            <h6 class="fw-bold text-dark mb-0">Bagas Eko Setiawan</h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 rounded-3 border bg-light h-100 text-center">
                            <div class="bg-dark text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                <i class="bi bi-person-fill fs-4"></i>
                            </div>
                            <h6 class="fw-bold text-dark mb-0">Fatdhri Wijaya</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?= $this->endSection() ?>
