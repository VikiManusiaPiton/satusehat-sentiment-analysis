<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'SatuSehat Sentiment Analyzer') ?></title>
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>

    <style>
        :root {
            --satusehat-primary: #0284c7;
            --satusehat-dark: #0369a1;
            --satusehat-teal: #0d9488;
            --satusehat-soft: #f0fdfa;
            --pos-color: #10b981;
            --pos-bg: #d1fae5;
            --pos-text: #065f46;
            --neg-color: #ef4444;
            --neg-bg: #fee2e2;
            --neg-text: #991b1b;
        }

        body {
            font-family: 'Plus Jakarta Sans', 'Inter', sans-serif;
            background-color: #f8fafc;
            color: #1e293b;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .navbar-brand-logo {
            background: linear-gradient(135deg, #0284c7 0%, #0d9488 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .navbar {
            background-color: #ffffff !important;
            border-bottom: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
        }

        .nav-link {
            font-weight: 500;
            color: #475569;
            padding: 0.5rem 0.9rem !important;
            border-radius: 8px;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: #0284c7 !important;
            background-color: #f0f9ff;
        }

        .card {
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card-header {
            background-color: #ffffff;
            border-bottom: 1px solid #f1f5f9;
            font-weight: 600;
            border-top-left-radius: 14px !important;
            border-top-right-radius: 14px !important;
        }

        .badge-positive {
            background-color: var(--pos-bg);
            color: var(--pos-text);
            border: 1px solid #a7f3d0;
            font-weight: 600;
        }

        .badge-negative {
            background-color: var(--neg-bg);
            color: var(--neg-text);
            border: 1px solid #fecaca;
            font-weight: 600;
        }

        /* Highlighting words in review */
        .highlight-pos {
            background-color: #bbf7d0;
            color: #065f46;
            padding: 2px 5px;
            border-radius: 4px;
            font-weight: 600;
            text-decoration: underline wavy #10b981;
        }

        .highlight-neg {
            background-color: #fecaca;
            color: #991b1b;
            padding: 2px 5px;
            border-radius: 4px;
            font-weight: 600;
            text-decoration: underline wavy #ef4444;
        }

        .word-bubble {
            display: inline-block;
            padding: 0.4rem 0.8rem;
            margin: 0.25rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .word-bubble.pos {
            background-color: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }

        .word-bubble.neg {
            background-color: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }

        .footer {
            margin-top: auto;
            background-color: #ffffff;
            border-top: 1px solid #e2e8f0;
            padding: 1.5rem 0;
            color: #64748b;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="<?= base_url('/') ?>">
                <div class="bg-primary text-white rounded-3 p-1 px-2 d-flex align-items-center justify-content-center" style="width:36px; height:36px; background: linear-gradient(135deg, #0284c7, #0d9488) !important;">
                    <i class="bi bi-heart-pulse-fill fs-5"></i>
                </div>
                <div>
                    <span class="navbar-brand-logo fs-5">SATUSEHAT</span>
                    <small class="text-secondary d-none d-sm-inline ms-1 font-monospace" style="font-size: 0.75rem;">Sentiment AI</small>
                </div>
            </a>
            
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === '' || uri_string() === 'analisis' ? 'active' : '' ?>" href="<?= base_url('/analisis') ?>">
                            <i class="bi bi-chat-square-text me-1"></i> Analisis Ulasan
                        </a>
                    </li>
                    <?php if (session()->get('isLoggedIn')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'dashboard' ? 'active' : '' ?>" href="<?= base_url('/dashboard') ?>">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'riwayat' ? 'active' : '' ?>" href="<?= base_url('/riwayat') ?>">
                            <i class="bi bi-clock-history me-1"></i> Riwayat
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'batch' ? 'active' : '' ?>" href="<?= base_url('/batch') ?>">
                            <i class="bi bi-file-earmark-spreadsheet me-1"></i> Prediksi Massal (CSV)
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'performa' ? 'active' : '' ?>" href="<?= base_url('/performa') ?>">
                            <i class="bi bi-graph-up-arrow me-1"></i> Performa Model
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'tentang' ? 'active' : '' ?>" href="<?= base_url('/tentang') ?>">
                            <i class="bi bi-info-circle me-1"></i> Tentang
                        </a>
                    </li>
                </ul>

                <div class="d-flex align-items-center gap-2">
                    <?php if (session()->get('isLoggedIn')): ?>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle d-flex align-items-center gap-2 py-1 px-3 rounded-pill" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle text-primary"></i>
                                <span class="fw-medium"><?= esc(session()->get('username') ?? 'Admin') ?></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                                <li><a class="dropdown-item" href="<?= base_url('/dashboard') ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard Admin</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= base_url('/auth/logout') ?>"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?= base_url('/auth/login') ?>" class="btn btn-sm btn-primary px-3 rounded-pill">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Login Admin
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content Container -->
    <main class="py-4 flex-grow-1">
        <div class="container">
            <!-- Flash Messages -->
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3 mb-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i>
                    <?= session()->getFlashdata('success') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3 mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2 fs-5 align-middle"></i>
                    <?= session()->getFlashdata('error') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Render Body -->
            <?= $this->renderSection('content') ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container text-center">
            <div class="row align-items-center">
                <div class="col-md-6 text-md-start mb-2 mb-md-0">
                    <span class="fw-semibold text-dark">SatuSehat Sentiment Analyzer</span> &copy; <?= date('Y') ?>
                    <div class="small text-muted">Model: Logistic Regression + TF-IDF (Dataset IGAR Mendeley DOI: 10.17632/7zryc6k76z.3)</div>
                </div>
                <div class="col-md-6 text-md-end small">
                    <span class="badge bg-light text-dark border me-1"><i class="bi bi-cpu me-1 text-primary"></i> FastAPI :5000</span>
                    <span class="badge bg-light text-dark border"><i class="bi bi-code-slash me-1 text-info"></i> CodeIgniter 4 :8080</span>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5.3 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?= $this->renderSection('scripts') ?>
</body>
</html>
