<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center py-4">
    <div class="col-md-5 col-lg-4">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4 p-md-5">
                <div class="text-center mb-4">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary bg-opacity-10 text-primary p-3 mb-3">
                        <i class="bi bi-shield-lock-fill fs-2"></i>
                    </div>
                    <h4 class="fw-bold text-dark mb-1">Masuk Administrator</h4>
                    <p class="text-muted small mb-0">Akses dashboard, riwayat ulasan, dan prediksi massal</p>
                </div>

                <form action="<?= base_url('/auth/login') ?>" method="post">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="username" class="form-label small fw-semibold text-secondary">Username</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light text-muted"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control" id="username" name="username" value="<?= old('username') ?>" placeholder="Masukkan username" required autofocus>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label small fw-semibold text-secondary">Password</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light text-muted"><i class="bi bi-key"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 rounded-pill fw-semibold shadow-sm mb-3">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Masuk Sekarang
                    </button>
                </form>

                <div class="alert alert-info py-2 px-3 small border-0 bg-info bg-opacity-10 rounded-3 mb-0">
                    <div class="fw-semibold text-info-emphasis mb-1"><i class="bi bi-info-circle-fill me-1"></i> Akun Bawaan (Default):</div>
                    <div class="text-secondary">
                        Username: <strong>admin</strong><br>
                        Password: <strong>admin123</strong>
                    </div>
                </div>

            </div>
        </div>

        <div class="text-center mt-3">
            <a href="<?= base_url('/analisis') ?>" class="text-decoration-none small text-muted">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke Halaman Analisis
            </a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
