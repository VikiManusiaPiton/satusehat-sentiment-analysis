<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-graph-up-arrow text-primary me-2"></i> Performa & Evaluasi Model Machine Learning
        </h3>
        <p class="text-secondary small mb-0">Evaluasi metrik kinerja model Logistic Regression + TF-IDF N-Gram dan komparasi skenario eksperimen preprocessing teks.</p>
    </div>
    <div>
        <span class="badge bg-light text-dark border p-2 px-3 rounded-pill shadow-sm">
            <i class="bi bi-hdd-network me-1 text-<?= $apiOnline ? 'success' : 'warning' ?>"></i>
            Sumber Data: <strong><?= $fromCache ? 'Local JSON Cache' : 'FastAPI (/metrics)' ?></strong>
        </span>
    </div>
</div>

<?php if ($errorMessage && empty($metrics)): ?>
    <div class="alert alert-warning shadow-sm rounded-3">
        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= esc($errorMessage) ?>
    </div>
<?php else: ?>

<!-- Metadata Model & Dataset -->
<div class="card mb-4 bg-light border-0">
    <div class="card-body p-4">
        <div class="row g-3">
            <div class="col-md-3">
                <span class="text-muted small fw-semibold text-uppercase">Algoritma & Model</span>
                <div class="fw-bold text-dark mt-1"><?= esc($metrics['model_info']['algorithm'] ?? 'Logistic Regression + TF-IDF (1,2)') ?></div>
            </div>
            <div class="col-md-3">
                <span class="text-muted small fw-semibold text-uppercase">Sumber Dataset</span>
                <div class="fw-bold text-dark mt-1"><?= esc($metrics['dataset_info']['source'] ?? 'IGAR Mendeley Data') ?></div>
            </div>
            <div class="col-md-3">
                <span class="text-muted small fw-semibold text-uppercase">Total Sampel Ulasan</span>
                <div class="fw-bold text-dark mt-1">
                    <?= number_format($metrics['dataset_info']['total_samples'] ?? 3994) ?> Baris
                    <span class="small text-muted fw-normal">(1.997 Positif / 1.997 Negatif)</span>
                </div>
            </div>
            <div class="col-md-3">
                <span class="text-muted small fw-semibold text-uppercase">Rasio Pembagian Data</span>
                <div class="fw-bold text-dark mt-1"><?= esc($metrics['dataset_info']['split_ratio'] ?? '80% Train : 20% Test') ?></div>
            </div>
        </div>
    </div>
</div>

<!-- 4 KPI Metrics Card (Akurasi, Presisi, Recall, F1) -->
<?php
    $eval = $metrics['evaluation'] ?? [];
    $acc = round(($eval['accuracy'] ?? 0) * 100, 2);
    $prec = round(($eval['precision'] ?? 0) * 100, 2);
    $rec = round(($eval['recall'] ?? 0) * 100, 2);
    $f1 = round(($eval['f1_score'] ?? 0) * 100, 2);
?>
<div class="row g-3 mb-4">
    <!-- Akurasi -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-top border-4 border-primary">
            <div class="card-body p-4 text-center">
                <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-1 rounded-pill mb-2 small fw-semibold">
                    Overall Metric
                </span>
                <h2 class="display-6 fw-bold text-dark mb-1"><?= $acc ?>%</h2>
                <div class="fw-bold text-secondary">Akurasi (Accuracy)</div>
                <small class="text-muted d-block mt-2">Proporsi total prediksi sentimen yang benar.</small>
            </div>
        </div>
    </div>

    <!-- Presisi -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-top border-4 border-success">
            <div class="card-body p-4 text-center">
                <span class="badge bg-success bg-opacity-10 text-success px-3 py-1 rounded-pill mb-2 small fw-semibold">
                    Quality Metric
                </span>
                <h2 class="display-6 fw-bold text-success mb-1"><?= $prec ?>%</h2>
                <div class="fw-bold text-secondary">Presisi (Precision)</div>
                <small class="text-muted d-block mt-2">Ketepatan saat memprediksi kelas positif.</small>
            </div>
        </div>
    </div>

    <!-- Recall -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-top border-4 border-info">
            <div class="card-body p-4 text-center">
                <span class="badge bg-info bg-opacity-10 text-info px-3 py-1 rounded-pill mb-2 small fw-semibold">
                    Coverage Metric
                </span>
                <h2 class="display-6 fw-bold text-info mb-1"><?= $rec ?>%</h2>
                <div class="fw-bold text-secondary">Daya Ingat (Recall)</div>
                <small class="text-muted d-block mt-2">Kemampuan menjaring seluruh data sentimen riil.</small>
            </div>
        </div>
    </div>

    <!-- F1 Score -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-top border-4 border-warning">
            <div class="card-body p-4 text-center">
                <span class="badge bg-warning bg-opacity-10 text-dark px-3 py-1 rounded-pill mb-2 small fw-semibold">
                    Harmonic Mean
                </span>
                <h2 class="display-6 fw-bold text-dark mb-1"><?= $f1 ?>%</h2>
                <div class="fw-bold text-secondary">F1-Score</div>
                <small class="text-muted d-block mt-2">Keseimbangan harmonik antara Presisi & Recall.</small>
            </div>
        </div>
    </div>
</div>

<!-- Section Confusion Matrix & Analisis -->
<div class="row g-4 mb-4">
    <!-- Confusion Matrix Heatmap Visual -->
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-dark">
                    <i class="bi bi-grid-3x3-gap-fill text-primary me-2"></i> Confusion Matrix (Heatmap)
                </span>
            </div>
            <div class="card-body p-4 d-flex flex-column justify-content-center">
                <?php
                    $cm = $eval['confusion_matrix'] ?? [[346, 54], [74, 325]];
                    $tn = $cm[0][0] ?? 0;
                    $fp = $cm[0][1] ?? 0;
                    $fn = $cm[1][0] ?? 0;
                    $tp = $cm[1][1] ?? 0;
                    $totalTest = $tn + $fp + $fn + $tp;
                ?>
                <div class="text-center mb-3">
                    <span class="text-muted small fw-semibold text-uppercase">Predicted Class</span>
                </div>

                <div class="row g-2 text-center align-items-center">
                    <div class="col-2 text-end">
                        <div class="small fw-bold text-muted rotate-text" style="writing-mode: vertical-lr; transform: rotate(180deg); margin: auto;">
                            Actual Class
                        </div>
                    </div>
                    <div class="col-10">
                        <div class="row g-2 mb-2">
                            <div class="col-6 small fw-semibold text-muted">Prediksi Negatif</div>
                            <div class="col-6 small fw-semibold text-muted">Prediksi Positif</div>
                        </div>
                        <div class="row g-2 mb-2">
                            <!-- TN -->
                            <div class="col-6">
                                <div class="p-3 rounded-3" style="background-color: #dbeafe; border: 1px solid #93c5fd;">
                                    <div class="fs-4 fw-bold text-primary"><?= number_format($tn) ?></div>
                                    <div class="small fw-semibold text-primary">True Negative (TN)</div>
                                    <div class="small text-muted" style="font-size:0.75rem;">Aktual Negatif, Prediksi Negatif</div>
                                </div>
                            </div>
                            <!-- FP -->
                            <div class="col-6">
                                <div class="p-3 rounded-3" style="background-color: #fee2e2; border: 1px solid #fca5a5;">
                                    <div class="fs-4 fw-bold text-danger"><?= number_format($fp) ?></div>
                                    <div class="small fw-semibold text-danger">False Positive (FP)</div>
                                    <div class="small text-muted" style="font-size:0.75rem;">Aktual Negatif, Prediksi Positif</div>
                                </div>
                            </div>
                        </div>
                        <div class="row g-2">
                            <!-- FN -->
                            <div class="col-6">
                                <div class="p-3 rounded-3" style="background-color: #fef3c7; border: 1px solid #fde68a;">
                                    <div class="fs-4 fw-bold text-warning-emphasis"><?= number_format($fn) ?></div>
                                    <div class="small fw-semibold text-warning-emphasis">False Negative (FN)</div>
                                    <div class="small text-muted" style="font-size:0.75rem;">Aktual Positif, Prediksi Negatif</div>
                                </div>
                            </div>
                            <!-- TP -->
                            <div class="col-6">
                                <div class="p-3 rounded-3" style="background-color: #d1fae5; border: 1px solid #86efac;">
                                    <div class="fs-4 fw-bold text-success"><?= number_format($tp) ?></div>
                                    <div class="small fw-semibold text-success">True Positive (TP)</div>
                                    <div class="small text-muted" style="font-size:0.75rem;">Aktual Positif, Prediksi Positif</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-4 pt-3 border-top small text-muted d-flex justify-content-between">
                    <span>Total Sampel Data Uji: <strong><?= number_format($totalTest) ?></strong> ulasan</span>
                    <span class="text-success fw-semibold"><i class="bi bi-check-circle-fill me-1"></i> Prediksi Benar: <?= number_format($tn + $tp) ?> (<?= round((($tn+$tp)/$totalTest)*100, 1) ?>%)</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart Ringkasan Metrik -->
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-dark">
                    <i class="bi bi-bar-chart-line-fill text-success me-2"></i> Perbandingan Metrik Evaluasi Utama
                </span>
            </div>
            <div class="card-body p-4">
                <div style="position: relative; height: 260px; width: 100%;">
                    <canvas id="metricsBarChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tabel Perbandingan Skenario Preprocessing & Ablation Study -->
<div class="card mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <div>
            <span class="fw-bold text-dark fs-5">
                <i class="bi bi-layers-fill text-primary me-2"></i> Perbandingan Skenario & Ablation Study
            </span>
            <div class="text-muted small mt-1">Eksperimen pengaruh n-gram dan representasi fitur teks terhadap performa model SATUSEHAT</div>
        </div>
        <span class="badge bg-success bg-opacity-10 text-success border border-success-subtle px-3 py-2 rounded-pill">
            <i class="bi bi-star-fill text-warning me-1"></i> Run 3 (Unigram+Bigram) Terbaik
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width: 260px;">Skenario / Run</th>
                        <th>Deskripsi Tahapan</th>
                        <th style="width: 110px;" class="text-center">Akurasi</th>
                        <th style="width: 110px;" class="text-center">Presisi</th>
                        <th style="width: 110px;" class="text-center">Recall</th>
                        <th style="width: 110px;" class="text-center">F1-Score</th>
                        <th style="width: 130px;" class="text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($metrics['scenarios_comparison'])): ?>
                        <?php foreach ($metrics['scenarios_comparison'] as $sc): ?>
                            <?php $isBest = !empty($sc['is_best']); ?>
                            <tr class="<?= $isBest ? 'table-success bg-opacity-25' : '' ?>">
                                <td>
                                    <div class="fw-bold <?= $isBest ? 'text-success' : 'text-dark' ?>">
                                        <?= esc($sc['nama']) ?>
                                    </div>
                                </td>
                                <td class="small text-muted">
                                    <?= esc($sc['deskripsi']) ?>
                                </td>
                                <td class="text-center fw-bold font-monospace <?= $isBest ? 'text-success' : '' ?>">
                                    <?= round($sc['accuracy'] * 100, 2) ?>%
                                </td>
                                <td class="text-center fw-bold font-monospace <?= $isBest ? 'text-success' : '' ?>">
                                    <?= round($sc['precision'] * 100, 2) ?>%
                                </td>
                                <td class="text-center fw-bold font-monospace <?= $isBest ? 'text-success' : '' ?>">
                                    <?= round($sc['recall'] * 100, 2) ?>%
                                </td>
                                <td class="text-center fw-bold font-monospace <?= $isBest ? 'text-success' : '' ?>">
                                    <?= round($sc['f1_score'] * 100, 2) ?>%
                                </td>
                                <td class="text-center">
                                    <?php if ($isBest): ?>
                                        <span class="badge bg-success px-3 py-2 rounded-pill shadow-sm">
                                            <i class="bi bi-check2-circle me-1"></i> Model Terpilih
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-muted border">
                                            Uji Coba
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php endif; ?>

<?= $this->section('scripts') ?>
<script>
    const ctx = document.getElementById('metricsBarChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Accuracy', 'Precision', 'Recall', 'F1-Score'],
            datasets: [{
                label: 'Nilai (%)',
                data: [<?= $acc ?>, <?= $prec ?>, <?= $rec ?>, <?= $f1 ?>],
                backgroundColor: [
                    '#0284c7',
                    '#10b981',
                    '#06b6d4',
                    '#f59e0b'
                ],
                borderRadius: 8,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    min: 70,
                    max: 100,
                    ticks: {
                        callback: function(value) { return value + "%"; },
                        font: { family: 'Plus Jakarta Sans' }
                    }
                },
                x: {
                    ticks: { font: { family: 'Plus Jakarta Sans', weight: 'bold' } }
                }
            }
        }
    });
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>
