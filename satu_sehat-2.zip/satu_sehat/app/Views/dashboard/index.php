<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-speedometer2 text-primary me-2"></i> Dashboard Analitik Sentimen
        </h3>
        <p class="text-secondary small mb-0">Agregasi hasil analisis ulasan SATUSEHAT, distribusi sentimen, tren waktu, dan deteksi keluhan pengguna.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= base_url('/batch') ?>" class="btn btn-outline-primary btn-sm rounded-pill px-3">
            <i class="bi bi-cloud-arrow-up me-1"></i> Upload CSV Massal
        </a>
        <a href="<?= base_url('/analisis') ?>" class="btn btn-primary btn-sm rounded-pill px-3">
            <i class="bi bi-plus-circle me-1"></i> Analisis Baru
        </a>
    </div>
</div>

<!-- KPI Summary Cards -->
<div class="row g-3 mb-4">
    <!-- Total Analisis -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-start border-4 border-primary">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Total Analisis</span>
                        <h3 class="fw-bold mb-0 text-dark mt-1"><?= number_format($stats['total'] ?? 0) ?></h3>
                    </div>
                    <div class="bg-primary bg-opacity-10 text-primary p-3 rounded-3">
                        <i class="bi bi-chat-left-text-fill fs-4"></i>
                    </div>
                </div>
                <div class="mt-2 text-muted small">
                    <i class="bi bi-database me-1 text-primary"></i> Data ulasan tersimpan
                </div>
            </div>
        </div>
    </div>

    <!-- Sentimen Positif -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-start border-4 border-success">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Ulasan Positif</span>
                        <h3 class="fw-bold mb-0 text-success mt-1"><?= number_format($stats['positive_count'] ?? 0) ?></h3>
                    </div>
                    <div class="bg-success bg-opacity-10 text-success p-3 rounded-3">
                        <i class="bi bi-hand-thumbs-up-fill fs-4"></i>
                    </div>
                </div>
                <div class="mt-2 text-success small fw-semibold">
                    <i class="bi bi-pie-chart-fill me-1"></i> <?= $stats['positive_pct'] ?? 0 ?>% dari total ulasan
                </div>
            </div>
        </div>
    </div>

    <!-- Sentimen Negatif -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-start border-4 border-danger">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Ulasan Negatif</span>
                        <h3 class="fw-bold mb-0 text-danger mt-1"><?= number_format($stats['negative_count'] ?? 0) ?></h3>
                    </div>
                    <div class="bg-danger bg-opacity-10 text-danger p-3 rounded-3">
                        <i class="bi bi-hand-thumbs-down-fill fs-4"></i>
                    </div>
                </div>
                <div class="mt-2 text-danger small fw-semibold">
                    <i class="bi bi-pie-chart-fill me-1"></i> <?= $stats['negative_pct'] ?? 0 ?>% dari total ulasan
                </div>
            </div>
        </div>
    </div>

    <!-- Rata-rata Confidence -->
    <div class="col-sm-6 col-xl-3">
        <div class="card h-100 border-start border-4 border-info">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Rata-Rata Confidence</span>
                        <?php if ($stats['avg_confidence'] !== null): ?>
                            <h3 class="fw-bold mb-0 text-info mt-1"><?= $stats['avg_confidence'] ?>%</h3>
                        <?php else: ?>
                            <h3 class="fw-bold mb-0 text-muted fs-6 mt-2">Data belum tersedia</h3>
                        <?php endif; ?>
                    </div>
                    <div class="bg-info bg-opacity-10 text-info p-3 rounded-3">
                        <i class="bi bi-shield-check fs-4"></i>
                    </div>
                </div>
                <div class="mt-2 text-muted small">
                    <i class="bi bi-check-all me-1 text-info"></i> Keyakinan prediksi model
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Section 1: Pie Sentimen & Keluhan Terbanyak -->
<div class="row g-4 mb-4">
    <!-- Pie Chart Proporsi Sentimen -->
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-dark">
                    <i class="bi bi-pie-chart-fill text-primary me-2"></i> Proporsi Sentimen (Positif vs Negatif)
                </span>
            </div>
            <div class="card-body d-flex flex-column align-items-center justify-content-center p-4">
                <div style="position: relative; height: 260px; width: 100%;">
                    <canvas id="sentimentPieChart"></canvas>
                </div>
                <div class="d-flex justify-content-center gap-4 mt-3 small">
                    <div class="d-flex align-items-center gap-2">
                        <span class="d-inline-block rounded-circle" style="width: 12px; height: 12px; background-color: #10b981;"></span>
                        <span>Positif: <strong><?= $stats['positive_count'] ?? 0 ?></strong></span>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="d-inline-block rounded-circle" style="width: 12px; height: 12px; background-color: #ef4444;"></span>
                        <span>Negatif: <strong><?= $stats['negative_count'] ?? 0 ?></strong></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bar Chart Keluhan Terbanyak -->
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <span class="fw-bold text-dark">
                    <i class="bi bi-exclamation-octagon-fill text-danger me-2"></i> Keluhan Terbanyak (Ulasan Negatif)
                </span>
                <span class="badge bg-danger bg-opacity-10 text-danger border border-danger-subtle">Analisis Kategori</span>
            </div>
            <div class="card-body p-4">
                <div style="position: relative; height: 270px; width: 100%;">
                    <canvas id="complaintsBarChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Section 2: Tren Harian -->
<div class="card mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <span class="fw-bold text-dark">
            <i class="bi bi-graph-up text-primary me-2"></i> Grafik Tren Analisis Harian
        </span>
        <span class="text-muted small">Periode 14 Hari Terakhir</span>
    </div>
    <div class="card-body p-4">
        <div style="position: relative; height: 280px; width: 100%;">
            <canvas id="trendLineChart"></canvas>
        </div>
    </div>
</div>

<!-- Word Cloud / Daftar Kata Teratas -->
<div class="row g-4 mb-4">
    <!-- Kata Positif -->
    <div class="col-md-6">
        <div class="card h-100 border-top border-3 border-success">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-success">
                    <i class="bi bi-chat-heart-fill me-2"></i> Kata Kunci Teratas: Ulasan Positif
                </span>
            </div>
            <div class="card-body p-4">
                <div class="d-flex flex-wrap gap-1">
                    <?php if (!empty($topPositiveWords)): ?>
                        <?php foreach ($topPositiveWords as $pw): ?>
                            <span class="word-bubble pos">
                                <?= esc($pw['word']) ?>
                                <span class="badge rounded-pill bg-success ms-1"><?= $pw['count'] ?></span>
                            </span>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted small mb-0">Belum ada data kata kunci positif.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Kata Negatif -->
    <div class="col-md-6">
        <div class="card h-100 border-top border-3 border-danger">
            <div class="card-header bg-white py-3">
                <span class="fw-bold text-danger">
                    <i class="bi bi-chat-square-dots-fill me-2"></i> Kata Kunci Teratas: Ulasan Negatif
                </span>
            </div>
            <div class="card-body p-4">
                <div class="d-flex flex-wrap gap-1">
                    <?php if (!empty($topNegativeWords)): ?>
                        <?php foreach ($topNegativeWords as $nw): ?>
                            <span class="word-bubble neg">
                                <?= esc($nw['word']) ?>
                                <span class="badge rounded-pill bg-danger ms-1"><?= $nw['count'] ?></span>
                            </span>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted small mb-0">Belum ada data kata kunci negatif.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->section('scripts') ?>
<script>
    // 1. Pie Chart Sentimen
    const pieCtx = document.getElementById('sentimentPieChart').getContext('2d');
    new Chart(pieCtx, {
        type: 'doughnut',
        data: {
            labels: ['Positif', 'Negatif'],
            datasets: [{
                data: [<?= (int)($stats['positive_count'] ?? 0) ?>, <?= (int)($stats['negative_count'] ?? 0) ?>],
                backgroundColor: ['#10b981', '#ef4444'],
                hoverBackgroundColor: ['#059669', '#dc2626'],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 14,
                        font: { family: 'Plus Jakarta Sans', size: 12 }
                    }
                }
            },
            cutout: '65%'
        }
    });

    // 2. Bar Chart Keluhan Terbanyak
    <?php
        $compLabels = [];
        $compCounts = [];
        foreach ($topComplaints as $tc) {
            $compLabels[] = $tc['category'] ?? 'Lainnya';
            $compCounts[] = (int)$tc['count'];
        }
    ?>
    const compCtx = document.getElementById('complaintsBarChart').getContext('2d');
    new Chart(compCtx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($compLabels) ?>,
            datasets: [{
                label: 'Jumlah Ulasan',
                data: <?= json_encode($compCounts) ?>,
                backgroundColor: '#f87171',
                borderColor: '#ef4444',
                borderWidth: 1,
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { precision: 0, font: { family: 'Plus Jakarta Sans' } }
                },
                y: {
                    ticks: { font: { family: 'Plus Jakarta Sans', size: 11 } }
                }
            }
        }
    });

    // 3. Line Chart Tren Harian
    <?php
        $trendDates = [];
        $trendPos = [];
        $trendNeg = [];
        foreach ($dailyTrends as $dt) {
            $trendDates[] = date('d M', strtotime($dt['date']));
            $trendPos[] = $dt['positif'];
            $trendNeg[] = $dt['negatif'];
        }
    ?>
    const trendCtx = document.getElementById('trendLineChart').getContext('2d');
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode($trendDates) ?>,
            datasets: [
                {
                    label: 'Positif',
                    data: <?= json_encode($trendPos) ?>,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.3,
                    fill: true,
                    borderWidth: 2,
                    pointRadius: 4
                },
                {
                    label: 'Negatif',
                    data: <?= json_encode($trendNeg) ?>,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    tension: 0.3,
                    fill: true,
                    borderWidth: 2,
                    pointRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { font: { family: 'Plus Jakarta Sans', size: 12 } }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0, font: { family: 'Plus Jakarta Sans' } }
                },
                x: {
                    ticks: { font: { family: 'Plus Jakarta Sans' } }
                }
            }
        }
    });
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>
