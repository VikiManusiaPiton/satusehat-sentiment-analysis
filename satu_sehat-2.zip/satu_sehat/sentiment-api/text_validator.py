import os
import re
import json
import pkgutil
from typing import Tuple, List
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory

# 1. Inisialisasi Stemmer dan Kamus Kata Dasar Sastrawi
_factory = StemmerFactory()
_stemmer = _factory.create_stemmer()

_sastrawi_data = pkgutil.get_data('Sastrawi', 'Stemmer/data/kata-dasar.txt')
SASTRAWI_WORDS = set(_sastrawi_data.decode('utf-8').splitlines()) if _sastrawi_data else set()

# 2. Tambahan kosakata istilah teknologi, slang, dan domain SATUSEHAT
DOMAIN_AND_SLANG_WORDS = {
    "satusehat", "pedulilindungi", "vaksin", "vaksinasi", "booster", "faskes", 
    "otp", "login", "error", "bug", "lemot", "crash", "install", "update", 
    "aplikasi", "apk", "app", "apps", "download", "nik", "ktp", "bpjs", 
    "sms", "email", "server", "admin", "gak", "nggak", "ga", "ngga", "udh", 
    "udah", "bgt", "banget", "sy", "saya", "yg", "yang", "dgn", "dengan", 
    "kalo", "kalau", "aja", "saja", "dr", "dari", "sdh", "sudah", "dong", 
    "deh", "pas", "tau", "kok", "nya", "pasien", "dokter", "rs", "puskesmas", 
    "sertifikat", "scan", "barcode", "qris", "qr", "loading", "fitur", "versi", 
    "bintang", "playstore", "developer", "kecewa", "parah", "bisa", "tolong", 
    "mohon", "kenapa", "gimana", "bagaimana", "cepat", "lambat", "lancar", 
    "mudah", "sulit", "ribet", "bagus", "buruk", "mantap", "keren", "terima", 
    "kasih", "terimakasih", "makasih", "halo", "hai", "oke", "ok", "sip",
    "buka", "tutup", "akun", "daftar", "verifikasi", "data", "sistem", "jaringan",
    "koneksi", "sinyal", "kuota", "internet", "hp", "handphone", "layar",
    "notif", "notifikasi", "reload", "relog", "force", "close", "restart",
    "bantuan", "cs", "cust", "service", "customer", "komplain", "lapor",
    "rating", "ulasan", "review", "tanggap", "respons", "responsif", "respon",
    "ramah", "sukses", "gagal", "masuk", "keluar", "kirim", "terkirim",
    "terus", "selalu", "sering", "kadang", "tolonglah", "solusinya", "perbaiki",
    "bagusin", "hancur", "ancur", "rusak", "ilang", "hilang", "muncul", "bintang1",
    "bintang5", "mantul", "jos", "top", "good", "bad", "slow", "fast", "thanks",
    "sukses", "sia", "sia2", "capek", "lelah", "muak", "jengkel", "kesal", "kzl"
}

# 3. Load daftar kata kasar bahasa Indonesia dari profanity_id.json
PROFANITY_FILE = os.path.join(os.path.dirname(__file__), "profanity_id.json")
try:
    with open(PROFANITY_FILE, "r", encoding="utf-8") as f:
        PROFANITY_LIST = json.load(f)
except Exception:
    PROFANITY_LIST = [
        "anjing", "anjir", "anying", "asu", "babi", "bacot", "bajingan", 
        "bangke", "bangsat", "bego", "biadab", "bodoh", "brengsek", "cacat", 
        "cukimai", "dajjal", "goblok", "goblog", "idiot", "itil", "jablay", 
        "jancok", "jancuk", "jembut", "kampret", "keparat", "kimak", "kontol", 
        "lonte", "matamu", "memek", "monyet", "ndasmu", "ngentot", "ngewe", 
        "pantek", "peler", "perek", "puki", "pukimak", "setan", "sialan", 
        "sinting", "sontoloyo", "sundal", "tai", "taek", "taik", "titit", "tolol"
    ]

# Gabungan seluruh kata yang dikenal (kamus Sastrawi + domain slang + profanity)
ALL_KNOWN_WORDS = SASTRAWI_WORDS | DOMAIN_AND_SLANG_WORDS | set(PROFANITY_LIST)

# Leetspeak translation map
LEET_MAP = str.maketrans({
    '0': 'o',
    '1': 'i',
    '!': 'i',
    '|': 'i',
    '3': 'e',
    '4': 'a',
    '@': 'a',
    '5': 's',
    '$': 's',
    '7': 't',
    '8': 'b',
    '9': 'g',
})

def is_word_valid(word: str) -> bool:
    """Cek apakah kata ada di kamus kata dasar, domain list, atau bentuk dasarnya setelah distem."""
    w = word.lower()
    if w in ALL_KNOWN_WORDS:
        return True
    stemmed = _stemmer.stem(w)
    if stemmed in ALL_KNOWN_WORDS:
        return True
    return False

def check_profanity(text: str) -> Tuple[bool, List[str]]:
    """
    Lapisan A: Deteksi Kata Kasar (Profanity Filter)
    - Normalisasi: lowercase, hilangkan tanda baca, tangani leetspeak (4nj1ng, g0bl0k),
      dan pengulangan karakter (anjiiing).
    - Cocokkan per kata utuh (word boundary \\b).
    - Mengembalikan (has_profanity: bool, detected_words: list[str]).
    """
    raw_lower = text.lower()
    
    # 1. Versi normal teks (tanda baca diganti spasi)
    cleaned_spaces = re.sub(r'[^a-zA-Z0-9\s]', ' ', raw_lower)
    
    # 2. Versi leetspeak decode (misal 4nj1ng -> anjing)
    leet_decoded = cleaned_spaces.translate(LEET_MAP)

    # 3. Versi collapsed repeat chars (misal anjiiing -> anjing)
    collapsed = re.sub(r'(.)\1{2,}', r'\1', cleaned_spaces)
    leet_collapsed = re.sub(r'(.)\1{2,}', r'\1', leet_decoded)

    detected = set()

    for bad_word in PROFANITY_LIST:
        pattern = r'\b' + re.escape(bad_word) + r'\b'
        if re.search(pattern, cleaned_spaces):
            detected.add(bad_word)
        elif re.search(pattern, leet_decoded):
            detected.add(bad_word)
        elif re.search(pattern, collapsed):
            detected.add(bad_word)
        elif re.search(pattern, leet_collapsed):
            detected.add(bad_word)

    return (len(detected) > 0), sorted(list(detected))

def is_gibberish(text: str) -> Tuple[bool, str]:
    """
    Lapisan B: Deteksi Teks Tidak Jelas (Gibberish Filter)
    Tolak teks sebagai 'Tidak valid' jika memenuhi salah satu:
    1. Kurang dari 3 karakter huruf alfabet atau hanya angka/simbol/emoji.
    2. Karakter yang sama berulang > 4 kali (misal aaaaaa).
    3. Deret konsonan beruntun > 4 (misal asdfghjkl).
    4. Deret vokal beruntun >= 4 (misal keksnanakhdcaiao -> aiao).
    5. Rasio vokal terhadap huruf tidak wajar (< 20% atau > 80%).
    6. Sebagian besar kata tidak dikenal di kamus bahasa Indonesia (< 40%).
    
    Catatan: Jika teks terdeteksi mengandung kata kasar, teks bukan gibberish acak.
    """
    stripped = text.strip() if text else ""
    if not stripped:
        return True, "Teks kosong."

    # 1. Kurang dari 3 huruf alfabet atau hanya angka/simbol
    letters = [c for c in stripped.lower() if 'a' <= c <= 'z']
    if len(letters) < 3:
        return True, "Teks kurang dari 3 karakter huruf alfabet atau hanya angka/simbol."

    # Jika teks mengandung kata kasar (seperti 'anjing cacat goblok' atau leet '4nj1ng g0bl0k'),
    # maka teks ini adalah umpatan nyata (bukan ketikan acak/gibberish)
    has_bad_words, _ = check_profanity(stripped)
    if has_bad_words:
        return False, ""

    lower_text = stripped.lower()

    # 2. Karakter yang sama berulang > 4 kali (misal 'aaaaaa', 'zzzzz')
    if re.search(r'(.)\1{4,}', lower_text):
        return True, "Terdapat karakter yang berulang lebih dari 4 kali."

    # 3. Deret konsonan beruntun > 4 (misal 'asdfghjkl')
    if re.search(r'[bcdfghjklmnpqrstvwxyz]{5,}', lower_text):
        return True, "Terdapat deret konsonan beruntun lebih dari 4 huruf."

    # 4. Deret vokal beruntun >= 4 (misal 'aiao' di 'keksnanakhdcaiao')
    if re.search(r'[aeiou]{4,}', lower_text):
        return True, "Terdapat deret vokal beruntun tidak wajar."

    # 5. Rasio vokal terhadap huruf tidak wajar (< 20% atau > 80%) untuk teks >= 4 huruf
    if len(letters) >= 4:
        vowel_count = sum(1 for c in letters if c in 'aeiou')
        vowel_ratio = vowel_count / len(letters)
        if vowel_ratio < 0.20 or vowel_ratio > 0.80:
            return True, f"Rasio vokal tidak wajar ({vowel_ratio:.1%})."

    # 6. Cek pengenalan kata di kamus bahasa Indonesia
    tokens = re.findall(r'[a-zA-Z]+', lower_text)
    if not tokens:
        return True, "Tidak ditemukan kata alfabet yang valid."

    substantive_tokens = [t for t in tokens if len(t) >= 3]
    if not substantive_tokens:
        substantive_tokens = tokens

    valid_words = [t for t in substantive_tokens if is_word_valid(t)]
    recognized_ratio = len(valid_words) / len(substantive_tokens)

    # Jika hanya 1 kata dan tidak ada di kamus (seperti 'keksnanakhdcaiao')
    if len(substantive_tokens) == 1 and len(valid_words) == 0:
        return True, "Kata tidak dikenali dalam kamus bahasa Indonesia."

    # Jika rasio kata valid < 40%
    if recognized_ratio < 0.40:
        return True, f"Sebagian besar kata ({100 - recognized_ratio * 100:.0f}%) tidak dikenali."

    return False, ""
