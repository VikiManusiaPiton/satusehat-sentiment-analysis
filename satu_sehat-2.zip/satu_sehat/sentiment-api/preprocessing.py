import re
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory

# Inisialisasi Stopword Remover dan Stemmer dari PySastrawi
_stop_factory = StopWordRemoverFactory()
_stopword_remover = _stop_factory.create_stop_word_remover()

_stem_factory = StemmerFactory()
_stemmer = _stem_factory.create_stemmer()

# Daftar stopword kustom tambahan bila diperlukan
CUSTOM_STOPWORDS = {
    'yg', 'dgn', 'nya', 'nih', 'dong', 'kan', 'sih', 'kok', 'deh', 'gue', 'gw', 'aku', 'saya'
}

def clean_text(text: str) -> str:
    """
    Membersihkan teks dari URL, mention, hashtag, angka, karakter khusus,
    dan melakukan case folding (huruf kecil).
    """
    if not isinstance(text, str):
        return ""
    
    # 1. Case folding
    text = text.lower()
    
    # 2. Hapus URL / link
    text = re.sub(r'https?://\S+|www\.\S+', ' ', text)
    
    # 3. Hapus mention (@username) dan hashtag (#hashtag)
    text = re.sub(r'[@#]\S+', ' ', text)
    
    # 4. Hapus karakter selain huruf alfabet a-z dan spasi
    text = re.sub(r'[^a-z\s]', ' ', text)
    
    # 5. Normalisasi spasi ganda/berulang
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def remove_stopwords(text: str) -> str:
    """
    Menghapus stopword bahasa Indonesia menggunakan PySastrawi
    dan kata-kata singkatan tambahan.
    """
    if not text:
        return ""
    # PySastrawi stopword remover
    text = _stopword_remover.remove(text)
    
    # Filter kata custom tambahan
    words = [w for w in text.split() if w not in CUSTOM_STOPWORDS]
    return " ".join(words)

# Cache memori stemming kata dasar untuk optimasi performa ribuan ulasan
_stem_cache = {}

def stem_text(text: str) -> str:
    """
    Melakukan stemming kata bahasa Indonesia ke bentuk kata dasar menggunakan PySastrawi
    dengan dictionary cache agar pemrosesan ribuan baris berjalan secepat kilat.
    """
    if not text:
        return ""
    words = text.split()
    stemmed_words = []
    for w in words:
        if w not in _stem_cache:
            _stem_cache[w] = _stemmer.stem(w)
        stemmed_words.append(_stem_cache[w])
    return " ".join(stemmed_words)

def preprocess_text(text: str, apply_stemming: bool = True) -> str:
    """
    Pipeline lengkap preprocessing:
    1. Cleaning & Case Folding
    2. Stopword Removal
    3. Stemming (opsional, default True)
    """
    cleaned = clean_text(text)
    without_stopwords = remove_stopwords(cleaned)
    if apply_stemming:
        return stem_text(without_stopwords)
    return without_stopwords
