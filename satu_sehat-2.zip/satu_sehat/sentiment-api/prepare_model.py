import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)

from preprocessing import clean_text

# ─────────────────────────────────────────────────────────────────────────────
# Lokasi Dataset Riil SATUSEHAT
# ─────────────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "model")
CANDIDATE_PATHS = [
    r"C:\Users\MyBook Hype AMD\Documents\machine learning python\SATUSEHAT_clean_balanced.csv",
    os.path.join(BASE_DIR, "dataset", "SATUSEHAT_clean_balanced.csv"),
    os.path.join(BASE_DIR, "SATUSEHAT_clean_balanced.csv"),
]

def load_and_validate_dataset(candidate_paths: list) -> tuple:
    """
    Membaca dan memvalidasi dataset SATUSEHAT_clean_balanced.csv.
    Dataset riil ulasan Google Play Store:
    - 3.994 baris
    - Kolom 'content': teks ulasan pengguna
    - Kolom 'labelScoreBase': sentimen ('Positive' / 'Negative')
    """
    valid_path = None
    for p in candidate_paths:
        if os.path.exists(p):
            valid_path = p
            break

    if not valid_path:
        raise FileNotFoundError(f"Dataset tidak ditemukan pada salah satu path: {candidate_paths}")

    df = pd.read_csv(valid_path, sep=';')
    required_cols = {'content', 'labelScoreBase'}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"CSV harus memiliki kolom {required_cols}. Kolom tersedia: {df.columns.tolist()}")

    # Validasi dan pembersihan data kosong
    df = df.dropna(subset=['content', 'labelScoreBase']).copy()
    df['content'] = df['content'].astype(str).str.strip()
    df = df[df['content'] != ''].reset_index(drop=True)

    return df, valid_path

def train_and_evaluate():
    print("=================================================================")
    print(" 1. Memuat Dataset Ulasan SATUSEHAT Riil (Google Play Store)")
    print("=================================================================")
    df, actual_csv_path = load_and_validate_dataset(CANDIDATE_PATHS)
    print(f"   -> Path Dataset Terpilih: {actual_csv_path}")
    total_samples = len(df)
    pos_count = int((df['labelScoreBase'] == 'Positive').sum())
    neg_count = int((df['labelScoreBase'] == 'Negative').sum())

    print(f"   -> Total Baris Data : {total_samples}")
    print(f"   -> Distribusi Label : Positive = {pos_count} | Negative = {neg_count}")

    os.makedirs(MODEL_DIR, exist_ok=True)

    # Simpan sample CSV untuk pengujian batch upload di web app
    sample_df = df.sample(n=min(100, total_samples), random_state=42)[["content"]]
    sample_csv_path = os.path.join(BASE_DIR, "sample_ulasan_satusehat.csv")
    sample_df.to_csv(sample_csv_path, index=False)
    print(f"   -> File sample CSV disimpan: {sample_csv_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # 2. Split Data: 80% Train & 20% Test (Identik Notebook)
    # ─────────────────────────────────────────────────────────────────────────
    print("\n=================================================================")
    print(" 2. Pembagian Data (Train-Test Split 80:20)")
    print("=================================================================")
    X = df['content']
    y = df['labelScoreBase']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"   -> Data Latih (Train) : {len(X_train)} sampel (80%)")
    print(f"   -> Data Uji   (Test)  : {len(X_test)} sampel (20%)")

    # ─────────────────────────────────────────────────────────────────────────
    # 3. TF-IDF N-gram (1, 2) Vectorizer (Identik Notebook Run 3)
    # ─────────────────────────────────────────────────────────────────────────
    print("\n=================================================================")
    print(" 3. Ekstraksi Fitur: TF-IDF N-Gram (1, 2) min_df=3")
    print("=================================================================")
    # Parameter default TfidfVectorizer:
    # lowercase=True, token_pattern=r"(?u)\b\w\w+\b", sublinear_tf=False, norm='l2'
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=3)
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)
    num_features = X_train_tfidf.shape[1]
    print(f"   -> Total Fitur TF-IDF : {num_features} kolom (Identik notebook = 3333)")

    # ─────────────────────────────────────────────────────────────────────────
    # 4. Pelatihan Model: Logistic Regression (C=1.0, max_iter=1000, random_state=42)
    # ─────────────────────────────────────────────────────────────────────────
    print("\n=================================================================")
    print(" 4. Pelatihan Model: Logistic Regression")
    print("=================================================================")
    model = LogisticRegression(C=1.0, max_iter=1000, random_state=42)
    model.fit(X_train_tfidf, y_train)
    print(f"   -> Kelas Model Terdaftar : {model.classes_.tolist()}")

    # ─────────────────────────────────────────────────────────────────────────
    # 5. Evaluasi Prediksi pada Test Set (Langsung Dihitung, No Hardcode)
    # ─────────────────────────────────────────────────────────────────────────
    print("\n=================================================================")
    print(" 5. Evaluasi Performa Model pada Data Uji (Test Set)")
    print("=================================================================")
    y_pred = model.predict(X_test_tfidf)
    
    # Deteksi indeks probabilitas kelas Positive
    pos_col_idx = list(model.classes_).index('Positive')
    y_prob = model.predict_proba(X_test_tfidf)[:, pos_col_idx]
    y_test_binary = (y_test == 'Positive').astype(int)

    acc = round(float(accuracy_score(y_test, y_pred)), 4)
    prec = round(float(precision_score(y_test, y_pred, pos_label='Positive')), 4)
    rec = round(float(recall_score(y_test, y_pred, pos_label='Positive')), 4)
    f1 = round(float(f1_score(y_test, y_pred, pos_label='Positive')), 4)
    auc = round(float(roc_auc_score(y_test_binary, y_prob)), 4)

    # Urutan Confusion Matrix standar: [[TN, FP], [FN, TP]]
    # labels=['Negative', 'Positive']:
    # Row 0: Aktual Negative -> Col 0: Pred Negative (TN), Col 1: Pred Positive (FP)
    # Row 1: Aktual Positive -> Col 0: Pred Negative (FN), Col 1: Pred Positive (TP)
    cm_array = confusion_matrix(y_test, y_pred, labels=['Negative', 'Positive'])
    cm = cm_array.tolist()

    print(f"   Accuracy  : {acc * 100:.2f}%")
    print(f"   Precision : {prec * 100:.2f}%")
    print(f"   Recall    : {rec * 100:.2f}%")
    print(f"   F1-Score  : {f1 * 100:.2f}%")
    print(f"   ROC AUC   : {auc:.4f}")
    print(f"   Confusion Matrix [TN, FP], [FN, TP]:")
    print(f"     TN: {cm[0][0]} | FP: {cm[0][1]}")
    print(f"     FN: {cm[1][0]} | TP: {cm[1][1]}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, digits=4))

    # ─────────────────────────────────────────────────────────────────────────
    # 6. Ablation Study & Komparasi Skenario Eksperimen (Dihitung Real)
    # ─────────────────────────────────────────────────────────────────────────
    print("=================================================================")
    print(" 6. Menghitung Metrik Ablation Study & Skenario Eksperimen")
    print("=================================================================")
    # Run 1: Unigram (1, 1)
    v1 = TfidfVectorizer(ngram_range=(1, 1), min_df=3)
    m1 = LogisticRegression(C=1.0, max_iter=1000, random_state=42).fit(v1.fit_transform(X_train), y_train)
    p1 = m1.predict(v1.transform(X_test))

    # Run 2: Bigram (2, 2)
    v2 = TfidfVectorizer(ngram_range=(2, 2), min_df=3)
    m2 = LogisticRegression(C=1.0, max_iter=1000, random_state=42).fit(v2.fit_transform(X_train), y_train)
    p2 = m2.predict(v2.transform(X_test))

    scenarios = [
        {
            "id": 1,
            "nama": "Run 1: TF-IDF Unigram (1, 1)",
            "deskripsi": f"Fitur kata tunggal ({v1.fit_transform(X_train).shape[1]} fitur), min_df=3, tanpa n-gram berturutan.",
            "accuracy": round(float(accuracy_score(y_test, p1)), 4),
            "precision": round(float(precision_score(y_test, p1, pos_label='Positive')), 4),
            "recall": round(float(recall_score(y_test, p1, pos_label='Positive')), 4),
            "f1_score": round(float(f1_score(y_test, p1, pos_label='Positive')), 4),
            "is_best": False
        },
        {
            "id": 2,
            "nama": "Run 2: TF-IDF Bigram (2, 2)",
            "deskripsi": f"Fitur pasangan dua kata ({v2.fit_transform(X_train).shape[1]} fitur), min_df=3, fokus konteks frase kata.",
            "accuracy": round(float(accuracy_score(y_test, p2)), 4),
            "precision": round(float(precision_score(y_test, p2, pos_label='Positive')), 4),
            "recall": round(float(recall_score(y_test, p2, pos_label='Positive')), 4),
            "f1_score": round(float(f1_score(y_test, p2, pos_label='Positive')), 4),
            "is_best": False
        },
        {
            "id": 3,
            "nama": "Run 3: TF-IDF Unigram + Bigram (1, 2) [Model Terpilih]",
            "deskripsi": f"Kombinasi kata tunggal & frasa ({num_features} fitur), min_df=3, Logistic Regression C=1.0.",
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "is_best": True
        }
    ]

    # ─────────────────────────────────────────────────────────────────────────
    # 7. Simpan Artefak Model & Metrics JSON
    # ─────────────────────────────────────────────────────────────────────────
    tfidf_file = os.path.join(MODEL_DIR, "tfidf.joblib")
    logreg_file = os.path.join(MODEL_DIR, "logreg.joblib")
    metrics_file = os.path.join(MODEL_DIR, "metrics.json")

    joblib.dump(vectorizer, tfidf_file)
    joblib.dump(model, logreg_file)

    metrics_data = {
        "dataset_info": {
            "source": "SATUSEHAT_clean_balanced.csv (Google Play Store reviews)",
            "total_samples": total_samples,
            "positive_samples": pos_count,
            "negative_samples": neg_count,
            "split_ratio": f"80% Train : 20% Test ({len(X_train)} latih, {len(X_test)} uji)"
        },
        "model_info": {
            "algorithm": "Logistic Regression + TF-IDF (1, 2) - Run 3",
            "classes": ["Negative (0)", "Positive (1)"],
            "features_count": num_features,
            "parameters": {
                "C": 1.0,
                "max_iter": 1000,
                "random_state": 42,
                "ngram_range": [1, 2],
                "min_df": 3
            }
        },
        "evaluation": {
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "roc_auc": auc,
            "confusion_matrix": cm
        },
        "scenarios_comparison": scenarios
    }

    with open(metrics_file, "w", encoding="utf-8") as f:
        json.dump(metrics_data, f, indent=4, ensure_ascii=False)

    print("\n=================================================================")
    print(" [OK] Pelatihan Model & Penyelarasan Evaluasi Selesai 100%!")
    print(f" -> tfidf.joblib  : {tfidf_file}")
    print(f" -> logreg.joblib : {logreg_file}")
    print(f" -> metrics.json  : {metrics_file}")
    print("=================================================================")

if __name__ == "__main__":
    train_and_evaluate()
