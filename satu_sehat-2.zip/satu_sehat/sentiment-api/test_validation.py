import unittest
from text_validator import is_gibberish, check_profanity
from main import analyze_single_text

class TestValidationLayers(unittest.TestCase):
    def test_profanity_detection(self):
        # 1. Teks kasar normal
        is_profane, words = check_profanity("anjing cacat goblok")
        self.assertTrue(is_profane)
        self.assertIn("anjing", words)
        self.assertIn("cacat", words)
        self.assertIn("goblok", words)

        # 2. Teks variasi leetspeak dan pengulangan huruf
        is_profane_leet, words_leet = check_profanity("4nj1ng g0bl0k anjiiing")
        self.assertTrue(is_profane_leet)
        self.assertIn("anjing", words_leet)
        self.assertIn("goblok", words_leet)

        # 3. Kata normal yang mengandung substring mirip (word boundary test)
        is_clean, words_clean = check_profanity("pantai ini sangat santai dan petai enak")
        self.assertFalse(is_clean)
        self.assertEqual(len(words_clean), 0)

    def test_gibberish_detection(self):
        # 1. Teks deret vokal beruntun tidak wajar
        gib, _ = is_gibberish("keksnanakhdcaiao")
        self.assertTrue(gib)

        # 2. Teks deret konsonan beruntun > 4
        gib, _ = is_gibberish("asdfghjkl")
        self.assertTrue(gib)

        # 3. Karakter berulang > 4 kali
        gib, _ = is_gibberish("aaaaaa")
        self.assertTrue(gib)

        # 4. Angka dan simbol tanpa huruf
        gib1, _ = is_gibberish("12345")
        gib2, _ = is_gibberish("!!!???")
        self.assertTrue(gib1)
        self.assertTrue(gib2)

        # 5. Kalimat ulasan valid
        gib_pos, _ = is_gibberish("pelayanannya cepat dan ramah")
        gib_neg, _ = is_gibberish("aplikasinya sering error dan lambat")
        self.assertFalse(gib_pos)
        self.assertFalse(gib_neg)

    def test_analyze_pipeline(self):
        # Kata kasar -> Negatif (Mengandung kata kasar), model dilewati
        res_prof = analyze_single_text("anjing cacat goblok")
        self.assertEqual(res_prof["label"], "Negatif")
        self.assertEqual(res_prof["category"], "Mengandung kata kasar")
        self.assertEqual(res_prof["status"], "profane")
        self.assertTrue(any(w["word"] == "anjing" for w in res_prof["top_words"]))

        # Gibberish -> Tidak Valid
        res_gib = analyze_single_text("keksnanakhdcaiao")
        self.assertEqual(res_gib["label"], "Tidak Valid")
        self.assertEqual(res_gib["confidence"], 0.0)
        self.assertEqual(res_gib["status"], "invalid")

        # Ulasan valid Positif
        res_pos = analyze_single_text("pelayanannya cepat dan ramah")
        self.assertEqual(res_pos["label"], "Positif")
        self.assertGreater(res_pos["confidence"], 0.7)

        # Ulasan valid Negatif
        res_neg = analyze_single_text("aplikasinya sering error dan lambat")
        self.assertEqual(res_neg["label"], "Negatif")
        self.assertGreater(res_neg["confidence"], 0.5)

if __name__ == "__main__":
    unittest.main()
