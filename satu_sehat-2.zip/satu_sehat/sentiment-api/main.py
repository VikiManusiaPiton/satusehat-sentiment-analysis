import os
import json
import joblib
import numpy as np
from typing import List, Optional
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from preprocessing import clean_text
from text_validator import is_gibberish, check_profanity

app = FastAPI(
    title="SatuSehat Sentiment API",
    description="API Analisis Sentimen Ulasan Pengguna Aplikasi SATUSEHAT menggunakan Logistic Regression + TF-IDF N-Gram (1, 2)",
    version="1.0.0"
)

# Konfigurasi CORS
origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://127.0.0.1",
    "http://127.0.0.1:8080",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

# Load model & vectorizer saat startup
MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
TFIDF_PATH = os.path.join(MODEL_DIR, "tfidf.joblib")
LOGREG_PATH = os.path.join(MODEL_DIR, "logreg.joblib")
METRICS_PATH = os.path.join(MODEL_DIR, "metrics.json")

try:
    vectorizer = joblib.load(TFIDF_PATH)
    model = joblib.load(LOGREG_PATH)
    feature_names = np.array(vectorizer.get_feature_names_out())
    coef = model.coef_[0]
    
    # Deteksi posisi indeks kelas model
    classes_list = list(model.classes_)
    neg_idx = classes_list.index("Negative") if "Negative" in classes_list else 0
    pos_idx = classes_list.index("Positive") if "Positive" in classes_list else 1
except Exception as e:
    vectorizer = None
    model = None
    feature_names = None
    coef = None
    neg_idx = 0
    pos_idx = 1
    print(f"Warning: Model gagal dimuat: {e}")

class PredictRequest(BaseModel):
    text: str = Field(..., description="Teks ulasan yang akan dianalisis, maksimal 1000 karakter")

    @field_validator("text")
    def validate_text(cls, v):
        stripped = v.strip() if v else ""
        if not stripped:
            raise ValueError("Teks ulasan tidak boleh kosong.")
        if len(v) > 1000:
            raise ValueError("Panjang teks ulasan maksimal 1000 karakter.")
        return stripped

class BatchPredictRequest(BaseModel):
    texts: List[str] = Field(..., description="Daftar teks ulasan yang akan dianalisis, maksimal 5.000 teks")

    @field_validator("texts")
    def validate_texts(cls, v):
        if not v or len(v) == 0:
            raise ValueError("Daftar ulasan tidak boleh kosong.")
        if len(v) > 5000:
            raise ValueError("Maksimal 5.000 teks per batch request.")
        return v

def analyze_single_text(text: str) -> dict:
    """
    Fungsi internal untuk menganalisis sentimen 1 teks:
    1. Lapisan Validasi Gibberish: Tolak jika teks tidak bermakna / acak
    2. Lapisan Validasi Kata Kasar: Langsung set Negatif jika mengandung kata kasar
    3. Pipeline Model Sentimen (TF-IDF N-gram 1-2 + Logistic Regression)
    """
    # 1. Validasi Gibberish Filter
    is_gib, reason = is_gibberish(text)
    if is_gib:
        return {
            "label": "Tidak Valid",
            "confidence": 0.0,
            "prob_positif": 0.0,
            "prob_negatif": 0.0,
            "clean_text": "",
            "top_words": [],
            "status": "invalid",
            "message": "Teks tidak dapat dianalisis. Mohon masukkan ulasan yang jelas.",
            "reason": reason
        }

    # 2. Validasi Kata Kasar (Profanity Filter)
    is_profane, bad_words = check_profanity(text)
    if is_profane:
        clean = clean_text(text)
        # Tampilkan kata kasar yang terdeteksi dengan bobot penentu negatif
        bad_word_weights = [{"word": w, "weight": -2.0} for w in bad_words]
        return {
            "label": "Negatif",
            "confidence": 0.99,
            "prob_positif": 0.01,
            "prob_negatif": 0.99,
            "clean_text": clean,
            "top_words": bad_word_weights,
            "status": "profane",
            "category": "Mengandung kata kasar",
            "note": "Mengandung kata kasar"
        }

    # 3. Model Sentimen ML (Logistic Regression + TF-IDF)
    clean = clean_text(text)
    tfidf_matrix = vectorizer.transform([clean if clean else text])
    
    # Predict Proba
    probs = model.predict_proba(tfidf_matrix)[0]
    prob_neg = float(probs[neg_idx])
    prob_pos = float(probs[pos_idx])

    if prob_pos >= prob_neg:
        label = "Positif"
        confidence = round(prob_pos, 4)
    else:
        label = "Negatif"
        confidence = round(prob_neg, 4)

    # Ekstraksi kata berpengaruh (top_words)
    non_zero_indices = tfidf_matrix.nonzero()[1]
    word_weights = []

    for idx in non_zero_indices:
        word = str(feature_names[idx])
        tfidf_val = tfidf_matrix[0, idx]
        weight = float(coef[idx] * tfidf_val)
        word_weights.append({
            "word": word,
            "weight": round(weight, 4)
        })

    # Urutkan berdasarkan nilai absolut kontribusi terbesar, ambil max 10
    word_weights.sort(key=lambda x: abs(x["weight"]), reverse=True)
    top_words = word_weights[:10]

    return {
        "label": label,
        "confidence": confidence,
        "prob_positif": round(prob_pos, 4),
        "prob_negatif": round(prob_neg, 4),
        "clean_text": clean,
        "top_words": top_words,
        "status": "valid"
    }

@app.get("/health", summary="Cek status kesehatan layanan API")
def health():
    if model is None or vectorizer is None:
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={"status": "error", "message": "Model belum dimuat"}
        )
    return {"status": "ok"}

@app.post("/predict", summary="Prediksi sentimen untuk 1 ulasan")
def predict(request: PredictRequest):
    if model is None or vectorizer is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model belum siap atau belum dimuat."
        )
    try:
        result = analyze_single_text(request.text)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan saat pemrosesan: {str(e)}"
        )

@app.post("/predict-batch", summary="Prediksi sentimen massal")
def predict_batch(request: BatchPredictRequest):
    if model is None or vectorizer is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model belum siap atau belum dimuat."
        )
    try:
        results = [None] * len(request.texts)
        indices_for_ml = []
        clean_texts_for_ml = []

        # 1. Jalankan pra-validasi (Gibberish & Profanity) untuk setiap baris
        for i, text in enumerate(request.texts):
            t = text.strip() if text else ""
            if not t:
                results[i] = {
                    "label": "Tidak Valid",
                    "confidence": 0.0,
                    "prob_positif": 0.0,
                    "prob_negatif": 0.0,
                    "clean_text": "",
                    "top_words": [],
                    "status": "invalid",
                    "message": "Teks tidak dapat dianalisis. Mohon masukkan ulasan yang jelas."
                }
                continue

            if len(t) > 1000:
                t = t[:1000]

            # Cek Gibberish
            is_gib, reason = is_gibberish(t)
            if is_gib:
                results[i] = {
                    "label": "Tidak Valid",
                    "confidence": 0.0,
                    "prob_positif": 0.0,
                    "prob_negatif": 0.0,
                    "clean_text": "",
                    "top_words": [],
                    "status": "invalid",
                    "message": "Teks tidak dapat dianalisis. Mohon masukkan ulasan yang jelas.",
                    "reason": reason
                }
                continue

            # Cek Profanity
            is_profane, bad_words = check_profanity(t)
            if is_profane:
                clean = clean_text(t)
                results[i] = {
                    "label": "Negatif",
                    "confidence": 0.99,
                    "prob_positif": 0.01,
                    "prob_negatif": 0.99,
                    "clean_text": clean,
                    "top_words": [{"word": w, "weight": -2.0} for w in bad_words],
                    "status": "profane",
                    "category": "Mengandung kata kasar",
                    "note": "Mengandung kata kasar"
                }
                continue

            # Jika lolos validasi, masukkan antrean prediksi model ML
            clean = clean_text(t)
            indices_for_ml.append(i)
            clean_texts_for_ml.append(clean if clean else t)

        # 2. Batch transform & predict ML untuk baris yang lolos validasi
        if indices_for_ml:
            tfidf_matrices = vectorizer.transform(clean_texts_for_ml)
            probs_all = model.predict_proba(tfidf_matrices)

            for ml_idx, orig_idx in enumerate(indices_for_ml):
                clean = clean_texts_for_ml[ml_idx]
                prob_neg = float(probs_all[ml_idx][neg_idx])
                prob_pos = float(probs_all[ml_idx][pos_idx])

                if prob_pos >= prob_neg:
                    label = "Positif"
                    conf = round(prob_pos, 4)
                else:
                    label = "Negatif"
                    conf = round(prob_neg, 4)

                row = tfidf_matrices.getrow(ml_idx)
                non_zero_indices = row.indices
                data_vals = row.data

                word_weights = []
                for col_idx, tfidf_val in zip(non_zero_indices, data_vals):
                    word = str(feature_names[col_idx])
                    weight = float(coef[col_idx] * tfidf_val)
                    word_weights.append({
                        "word": word,
                        "weight": round(weight, 4)
                    })

                word_weights.sort(key=lambda x: abs(x["weight"]), reverse=True)
                top_words = word_weights[:10]

                results[orig_idx] = {
                    "label": label,
                    "confidence": conf,
                    "prob_positif": round(prob_pos, 4),
                    "prob_negatif": round(prob_neg, 4),
                    "clean_text": clean,
                    "top_words": top_words,
                    "status": "valid"
                }

        return results
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan saat pemrosesan batch: {str(e)}"
        )

@app.get("/metrics", summary="Ambil data evaluasi dan metrik performa model")
def get_metrics():
    if not os.path.exists(METRICS_PATH):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File metrics.json tidak ditemukan."
        )
    try:
        with open(METRICS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Gagal membaca file metrics.json: {str(e)}"
        )

# Global Exception handler untuk format JSON rapi
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"status": "error", "message": str(exc)}
    )
