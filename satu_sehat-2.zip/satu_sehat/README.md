# SatuSehat Sentiment Analyzer (CodeIgniter 4 + Python FastAPI)

Aplikasi Web Analisis Sentimen Ulasan Pengguna Aplikasi **SATUSEHAT Mobile** (Google Play Store) berbasis Machine Learning (*Natural Language Processing*) dengan arsitektur microservices terpisah: **PHP CodeIgniter 4** untuk antarmuka web & database MySQL, serta **Python FastAPI** untuk inferensi model dan explainability.

---

## 🌟 Fitur Utama Aplikasi

1. **Analisis Sentimen Teks Tunggal**:
   - Prediksi klasifikasi biner: **Positif** (badge hijau) atau **Negatif** (badge merah).
   - Menghitung **Confidence Score** (persentase keyakinan prediksi, bukan akurasi global).
   - Probabilitas detail kelas: $P(\text{Positif})$ vs $P(\text{Negatif})$.
   - Penanganan error ramah jika API offline (*"Layanan analisis sedang tidak tersedia"*).

2. **Kata Kunci Berpengaruh (Model Explainability)**:
   - Menghitung kontribusi bobot kata: $w_i = \text{coef}_i \times \text{tfidf}_i$.
   - Bobot positif ($+$) mendorong prediksi ke arah sentimen Positif.
   - Bobot negatif ($-$) mendorong prediksi ke arah sentimen Negatif.
   - Diurutkan berdasarkan nilai absolut kontribusi terbesar (maksimal 10 kata).

3. **Highlight Kata Interaktif**:
   - Mewarnai teks ulasan secara langsung:
     - **Merah muda / merah** untuk kata yang mendorong sentimen Negatif.
     - **Hijau muda / hijau** untuk kata yang mendorong sentimen Positif.

4. **Deteksi Kategori Keluhan Otomatis (Ulasan Negatif)**:
   - Rule-based keyword matching ke dalam 6 kategori keluhan umum SatuSehat:
     1. `OTP/verifikasi` (*otp, kode, verifikasi, sms, email, wa*)
     2. `Sertifikat vaksin tidak muncul` (*sertifikat, vaksin, muncul, booster*)
     3. `Input data/tanggal lahir` (*tanggal lahir, nik, tidak bisa isi, format*)
     4. `Performa/error` (*lemot, error, force close, update, lag, blank, crash*)
     5. `Login/registrasi` (*login, daftar, registrasi gagal, password*)
     6. `Lokasi/scan QR` (*lokasi, radius, scan, barcode, qr, gps*)

5. **Prediksi Massal (Upload CSV) & Ekspor**:
   - Unggah berkas CSV (maksimal 5 MB / 1.000 baris) dengan kolom wajib: `content`.
   - Chunking otomatis per 100 baris saat dikirim ke Python API.
   - Tabel preview hasil klasifikasi instan.
   - Unduh berkas CSV hasil prediksi (kolom: `content`, `label`, `confidence`, `kategori_keluhan`).
   - Tersedia tombol unduh template/contoh file CSV.

6. **Dashboard Analitik & Visualisasi (Chart.js)**:
   - KPI Cards: Total Ulasan, Jumlah & Persentase Positif, Jumlah & Persentase Negatif, Rata-rata Confidence.
   - **Pie/Doughnut Chart**: Perbandingan proporsi sentimen Positif vs Negatif.
   - **Bar Chart Horizontal**: Distribusi kategori keluhan terbanyak pada ulasan negatif.
   - **Line Chart**: Tren volume analisis ulasan harian (14 hari terakhir).
   - **Word Cloud / Top Words**: Badges kata kunci teratas untuk ulasan Positif dan Negatif beserta frekuensinya.

7. **Halaman Performa Model & Evaluasi**:
   - Mengambil data langsung dari endpoint `/metrics`.
   - Menampilkan metrik evaluasi: **Accuracy**, **Precision**, **Recall**, dan **F1-Score**.
   - **Confusion Matrix Heatmap**: visualisasi matriks 2x2 (*True Positive, False Positive, True Negative, False Negative*).
   - **Tabel Komparasi 4 Skenario Preprocessing**:
     - *Skenario 1: Cleaning Saja*
     - *Skenario 2: Cleaning + Case Folding*
     - *Skenario 3: Cleaning + Case Folding + Stopword Removal*
     - *Skenario 4: Lengkap (+ Stemming Sastrawi)* -> **Ditandai sebagai Model Terpilih**.

8. **Sistem Autentikasi & Keamanan**:
   - Filter autentikasi (`AuthFilter`) untuk memproteksi halaman Admin (Dashboard, Riwayat, Batch Upload, Performa).
   - Halaman analisis tunggal dan halaman Tentang dapat diakses secara publik.
   - Sanitasi input, proteksi CSRF, prepared statements / Query Builder (cegah SQL Injection), dan output escaping (`esc()`).

9. **Halaman Tentang & Sitasi Ilmiah**:
   - Informasi dataset riset: **IGAR Mendeley Data (DOI: [10.17632/7zryc6k76z.3](https://doi.org/10.17632/7zryc6k76z.3))** dengan total 3.994 ulasan seimbang (1.997 positif, 1.997 negatif).
   - Metodologi NLP: Preprocessing Sastrawi, TF-IDF N-Gram (1, 2), Logistic Regression.

---

## 🏛️ Arsitektur Sistem

```
Browser (User/Admin)
       │
       ▼  (Port 8080)
┌──────────────────────────────────────────────┐
│       CodeIgniter 4 (PHP 8.2) Web App        │
│  - Controllers & Views (Bootstrap 5, Chart)  │
│  - SentimentClient (CURLRequest, timeout 10s)│
│  - MySQL Database (Predictions, Users, Batch)│
└──────────────────────┬───────────────────────┘
                       │ HTTP REST API (JSON)
                       ▼ (Port 5000)
┌──────────────────────────────────────────────┐
│           Python API (FastAPI)               │
│  - Preprocessing (Sastrawi Nazief & Adriani) │
│  - TF-IDF Vectorizer (tfidf.joblib)          │
│  - Logistic Regression (logreg.joblib)       │
│  - Explainability Engine (coef_ * tfidf)     │
└──────────────────────────────────────────────┘
```

---

## 📁 Struktur Direktori

```text
c:\xampp\htdocs\satu_sehat\
├── app/
│   ├── Config/
│   │   ├── Filters.php            # Registrasi alias filter 'auth'
│   │   └── Routes.php             # Rute publik & admin grup
│   ├── Controllers/
│   │   ├── Analisis.php           # Analisis tunggal & AJAX /analisis/prediksi
│   │   ├── Auth.php               # Login & logout admin
│   │   ├── Batch.php              # Upload CSV & ekspor hasil
│   │   ├── Dashboard.php          # Statistik KPI, chart, & keluhan
│   │   ├── Performa.php           # Metrik evaluasi & confusion matrix
│   │   ├── Riwayat.php            # Tabel data, filter, pagination, hapus
│   │   └── Tentang.php            # Informasi dataset Mendeley & tim
│   ├── Database/
│   │   ├── Migrations/
│   │   │   └── 2026-10-24-000001_CreateAppTables.php
│   │   └── Seeds/
│   │       ├── MainSeeder.php
│   │       ├── UserSeeder.php     # Akun admin default
│   │       └── SamplePredictionSeeder.php
│   ├── Filters/
│   │   └── AuthFilter.php         # Proteksi middleware session admin
│   ├── Libraries/
│   │   ├── ComplaintCategorizer.php # Keyword matching kategori keluhan
│   │   └── SentimentClient.php    # Pembungkus CURLRequest ke FastAPI
│   ├── Models/
│   │   ├── BatchUploadModel.php
│   │   ├── PredictionModel.php
│   │   └── UserModel.php
│   └── Views/
│       ├── analisis/index.php
│       ├── auth/login.php
│       ├── batch/index.php
│       ├── dashboard/index.php
│       ├── layout/main.php
│       ├── performa/index.php
│       ├── riwayat/index.php
│       └── tentang/index.php
├── sentiment-api/                 # Python FastAPI Service
│   ├── model/
│   │   ├── logreg.joblib          # Model Logistic Regression
│   │   ├── tfidf.joblib           # TF-IDF N-gram Vectorizer
│   │   └── metrics.json           # Hasil evaluasi 4 skenario
│   ├── main.py                    # FastAPI application & endpoints
│   ├── preprocessing.py           # Pipeline teks & PySastrawi
│   ├── prepare_model.py           # Skrip training/persiapan model
│   ├── requirements.txt           # Dependensi Python
│   ├── run_api.py                 # Runner Uvicorn port 5000
│   └── sample_ulasan_satusehat.csv# Berkas contoh untuk uji coba batch
├── .env                           # Konfigurasi CI4 & URL API
└── README.md
```

---

## 🚀 Panduan Instalasi & Menjalankan Aplikasi

### 1. Prasyarat Sistem
- **PHP** $\ge$ 8.2 dengan ekstensi: `curl`, `intl`, `mbstring`, `mysqli`, `pdo_mysql`, `json`.
- **Composer** $\ge$ 2.0.
- **MySQL / MariaDB** (via XAMPP).
- **Python** $\ge$ 3.10 (tersedia `pip`).

---

### 2. Menjalankan Python FastAPI Service

Buka terminal baru pada direktori `sentiment-api/`:

```powershell
cd c:\xampp\htdocs\satu_sehat\sentiment-api

# 1. Install dependensi Python
pip install -r requirements.txt

# 2. (Opsional) Jika ingin melatih ulang / meregenerasi model & metrics
python prepare_model.py

# 3. Jalankan FastAPI server di port 5000
uvicorn main:app --host 127.0.0.1 --port 5000
# atau: python run_api.py
```

Layanan Python API akan aktif di:
- **Health Check**: `http://127.0.0.1:5000/health`
- **Interactive Swagger Docs**: `http://127.0.0.1:5000/docs`

---

### 3. Konfigurasi & Menjalankan CodeIgniter 4

Buka terminal kedua pada root direktori proyek `c:\xampp\htdocs\satu_sehat`:

#### A. Pastikan MySQL XAMPP Aktif
Pastikan MySQL service di XAMPP Control Panel telah berstatus **Running** (Port 3306).

#### B. Konfigurasi `.env`
File `.env` sudah disediakan dan terkonfigurasi:
```ini
CI_ENVIRONMENT = development

app.baseURL = 'http://localhost:8080/'

database.default.hostname = localhost
database.default.database = satu_sehat
database.default.username = root
database.default.password = 
database.default.DBDriver = MySQLi
database.default.port = 3306

sentiment.api.url = http://127.0.0.1:5000
```

#### C. Jalankan Migrasi & Seeder Database
```powershell
cd c:\xampp\htdocs\satu_sehat

# Jalankan migrasi tabel users, predictions, dan batch_uploads
php spark migrate

# Jalankan seeder akun admin dan sampel data awal
php spark db:seed MainSeeder
```

#### D. Jalankan Server Web CodeIgniter 4
```powershell
php spark serve --port 8080
```

Aplikasi web dapat diakses di browser melalui:  
👉 **`http://localhost:8080/`**

---

## 🔐 Kredensial Administrator

| Role | Username | Password |
|---|---|---|
| **Admin** | `admin` | `admin123` |

Halaman login dapat diakses di: **`http://localhost:8080/auth/login`**.

---

## 🧪 Pengujian Fitur End-to-End

1. **Analisis Sentimen Tunggal (`/analisis`)**:
   - Ketik ulasan positif: *"Aplikasi SatuSehat sangat bagus dan memudahkan saya cek sertifikat vaksin."* -> Klik **Analisis Sentimen**.
   - Periksa badge label **Positif**, confidence score, dan kata highlight hijau (*mudah*, *bagus*, dll).
   - Ketik ulasan negatif: *"Kode OTP verifikasi tidak kunjung masuk ke sms dan email saya."* -> Klik **Analisis Sentimen**.
   - Periksa badge label **Negatif**, kategori keluhan terdeteksi **OTP/verifikasi**, dan kata highlight merah (*otp*, *sms*, dll).

2. **Dashboard Analitik (`/dashboard`)**:
   - Login admin terlebih dahulu.
   - Amati grafik Pie Sentimen, Bar Chart Keluhan Terbanyak, Tren Harian, dan kumpulan badge kata terpopuler.

3. **Prediksi Massal CSV (`/batch`)**:
   - Klik tombol **Unduh Contoh / Template CSV** atau gunakan file `sentiment-api/sample_ulasan_satusehat.csv`.
   - Unggah file CSV tersebut dan klik **Proses Prediksi Massal**.
   - Amati preview hasil dan klik **Unduh CSV Hasil** untuk mengunduh laporan spreadsheet.

4. **Riwayat (`/riwayat`)**:
   - Lakukan filter berdasarkan kata kunci ulasan, status label (Positif/Negatif), atau rentang tanggal.
   - Lakukan pengujian tombol hapus baris ulasan.

5. **Performa Model (`/performa`)**:
   - Tinjau nilai Akurasi, Presisi, Recall, F1-Score, visualisasi Confusion Matrix heatmap interaktif, serta tabel komparasi 4 skenario preprocessing teks.
